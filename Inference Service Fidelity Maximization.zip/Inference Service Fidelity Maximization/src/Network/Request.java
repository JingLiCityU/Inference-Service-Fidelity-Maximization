package Network;

public class Request { //query
	private int id;
	private int O_id; // the primary DT of the IoT device
	private int[] candi; //the candidate nodes for the possible placement of the master digital twin
	//private DTN DTN_r; // the requested DTN
	//private double query_size; // the requested DTN
	private double H; // the number of interations
	private double budget; // the number of interations
	private double[] Uvalues; // the uility of candidates
	private double[] Pvalues; // the allocated privacy budget of candidates
	private double residual; // the allocated privacy budget of candidates
	
	public Request(int id, int O_id, int[] candi, double H, double budget, double[][] trust_map, double[][] interact_map, double tao, double kappa) { // id, location, object, size of query result, issuing time
		this.id = id;
		this.O_id = O_id;
		this.candi = candi.clone();
		this.H = H;
		this.budget = budget;
		
		this.Uvalues = new double[candi.length];
		double tot_intract = 0;
		for (int i = 0; i < candi.length; i++) {
			int candi_id = candi[i];
			tot_intract += interact_map [candi_id][O_id];
		}
		for (int i = 0; i < candi.length; i++) {
			int candi_id = candi[i];
			this.Uvalues[i] = interact_map [candi_id][O_id] / tot_intract;
		}
		
		this.Pvalues = new double[candi.length];
		for (int i = 0; i < candi.length; i++) {
			int candi_id = candi[i];
			double trust = trust_map[candi_id][O_id];
			this.Pvalues[i] = (trust / (trust + tao)) * kappa;
		}
		
		this.residual = budget;
	}
	
	public Request(Request r) { // id, location, object, size of query result, issuing time
		this.id = r.id;
		this.O_id = r.O_id;
		this.candi = r.candi.clone();
		this.H = r.H;
		this.budget = r.budget;
		this.Uvalues = r.Uvalues.clone();
		this.Pvalues = r.Pvalues.clone();
		this.residual = r.residual;
	}
	
	public int getID() {
		return this.id;
	}
	
	public int getO_ID() {
		return this.O_id;
	}
	
	public int[] getCandi() {
		return this.candi;
	}
	
	public double getH() {
		return this.H;
	}
	
	public double getBudget() {
		return this.budget;
	}
	
	public double[] getUvalues() {
		return this.Uvalues;
	}
	
	public double[] getPvalues() {
		return this.Pvalues;
	}
	
	public double getRresidual() {
		return this.residual;
	}
	
	public boolean enough(double o) {
		if (this.residual >=o) {
			return true;
		}
		else 
			return false;
	}
	
	public void put (double o) {
		this.residual -= o;
	}
	
	
	public void remove (double o) {
		this.residual += o;
	}
	
	
	public void clear() {
		this.residual = this.budget;
	}
	
	public void print () {
		System.out.println("Id: "+ this.id + ", " + "budget: "+ this.budget + ", "+
				"residual: "+ this.residual);
	}


}

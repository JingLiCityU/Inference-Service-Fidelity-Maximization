package Network;

public class Node {
	private int id;
	private double capacity;
	private double residual;
	//private double procRate; // procRate 
	private double band_cap;
	private double resi_band; // the number of subchannels
	private double usage;
	private double proc_cost;
	private double bandwidth;
	
	public Node (int id, double capacity, double band_cap, double bandwidth, double proc_cost){
		this.id = id;
		this.capacity = capacity;
		this.residual = capacity;
		this.band_cap = band_cap;
		this.bandwidth = bandwidth;
		this.resi_band = band_cap;
		this.proc_cost = proc_cost;
		//this.procRate = procRate;
		//this.band = band;
	}
	
	public Node( Node n) {
		this.id = n.id;
		this.capacity = n.capacity;
		this.residual = n.residual;
		this.band_cap = n.band_cap;
		this.bandwidth = n.bandwidth;
		this.resi_band = n.band_cap;
		this.proc_cost = n.proc_cost;
		//this.procRate = n.procRate;
		//this.band = n.band;
	}
	
	public void Copy(Node n) {
		this.id = n.id;
		this.capacity = n.capacity;
		this.residual = n.residual;
		//this.procRate = n.procRate;
		this.band_cap = n.band_cap;
		this.bandwidth = n.bandwidth;
		this.resi_band = n.resi_band;
	}
	
	public void getNew(Node n) {
		this.id = n.id;
		this.capacity = n.capacity;
		this.residual = n.capacity;
		this.band_cap = n.band_cap;
		this.bandwidth = n.bandwidth;
		this.resi_band = n.band_cap;
		//this.procRate = n.procRate;
		//this.band = n.band;
	}
	
	public int getId () {
		return this.id;
	}
	
	public double getCapacity () {
		return this.capacity;
	}
	
	public double getUsed () {
		return this.capacity - this.residual;
	}
	
	public void setCapacity (double c) {
		this.capacity = c;
	}
	
	
	public double getResidual () {
		return this.residual;
	}
	
	public double getBand_cap () {
		return this.band_cap;
	}
	
	public double getBandwidth () {
		return this.bandwidth;
	}
	
	public double getResi_band () {
		return this.resi_band;
	}
	
	//public double getProcRate () {
	//	return this.procRate;
	//}
	
	//public double getBand () {
	//	return this.band;
	//}
	
	public boolean enough(double o) {
		if (this.residual >= o) {
			return true;
		}
		else 
			return false;
	}
	
	public boolean enough(DT i) {
		return enough(i.getConsump());
	}
	
	public boolean enough(model i) {
		return enough(i.getConsump());
	}
	
	public boolean enough_band(double o) {
		if (this.resi_band >= o) {
			return true;
		}
		else 
			return false;
	}
	
	public boolean enough_band(Objectt o) {
		//return enough_band(o.getBand()[this.id]);
		return enough_band(1);
	}
	
	public double getUsage() {
		return (this.capacity - this.residual) / this.capacity;
	}
	
	public double getBand_Usage() {
		return (this.band_cap - this.resi_band) / this.band_cap;
	}
	
	public void put (DT o) {
		this.residual -= o.getConsump();
	}
	
	public void put (model o) {
		this.residual -= o.getConsump();
	}
	
	public void put (Objectt o) {
		//this.resi_band -= o.getBand()[this.id];
		this.resi_band -= 1;
	}
	
	public double getProc_cost() {
		return this.proc_cost;
	}
	
	public void put (double o) {
		this.residual -= o;
	}
	
	
	public void remove (DT o) {
		this.residual += o.getConsump();
	}
	
	
	public void clear() {
		this.residual = this.capacity;
		this.resi_band = this.band_cap;
	}
	
	public void clear_band() {
		this.resi_band = this.band_cap;
	}
	
	public void print () {
		System.out.println("Id: "+ this.id + ", " + "capacity: "+ this.capacity + ", "+
				"residual: "+ this.residual);
	}

}
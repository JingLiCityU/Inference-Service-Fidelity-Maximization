package Network;

public class model {
	private int id;
	private int length;
	private int [] DTs;
	private double consump;
	private double proc_rate; 
	private double modelSize; 
	
	public model (int id, int length, int[] DTs, double comp, double proc_rate){ // the last one is the master digital twin
		this.id = id;
		this.length = DTs.length;
		this.DTs = DTs;
		this.consump = comp;
		this.proc_rate = proc_rate; 
		this.modelSize = comp/10;
	}
	
	
	//public double getDT_C(int i) {
	//	return this.DTs[i].getConsump();
	//}
	
	public int getId() {
		return this.id;
	}
	public int getLength() {
		return this.length;
	}
	public int[] getDTs() {
		return this.DTs;
	}
	
	public double getConsump(){
		return this.consump;
	}
	
	public double getProc_rate() {
		return this.proc_rate;
	}
	
	public double getModelSize() {
		return this.modelSize;
	}
	
}

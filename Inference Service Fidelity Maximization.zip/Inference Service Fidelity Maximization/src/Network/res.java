package Network;
import Simulation.*;

public class res {
	private double cost; // utility
	private long time;
	private double logTime;
	
	public res ( double cost, long time) {
		this.cost = cost; // mearsured by miao
		this.time = time;
		this.logTime = java.lang.Math.log10(time);
	}
	
	public double getCost(){
		return this.cost;
	}

	public double getTime(){
		return this.time;
	}
	
	public void setTime(long d){
		this.time = d;
		this.logTime = java.lang.Math.log10(d);
	}
	
	public double getLogTime(){
		return this.logTime;
	}
	public void print() {
		
		System.out.println("utility: "+ this.cost+ "s, " + "time: " + this.time + " ms" + ", " + "log10 time: " +logTime +"\n");
	}
}

package Network;

public class shortestPath {
	private String[] path;
	private double[] value;
	
	public shortestPath (String[]path, double[] value) {
		this.path = path.clone();
		this.value = value.clone();
	}
	
	public String[] getPath () {
		return this.path;
	}
	
	public double[] getValue() {
		return this.value;
	}

}

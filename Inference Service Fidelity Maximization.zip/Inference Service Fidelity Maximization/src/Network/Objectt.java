package Network;

public class Objectt {
	private int id;
	//private double update_size; //the data size of each update
	//private int update_interval; //the update interval
	//private double band; //the demanded computing resource of the digital twin
	//private double inst_delay; //the instantiation delay
	//private int[] locations;
	//private int retri; // the retrieving cloudlet, where the digital twin replica is placed
	private double transPower;
	private double channelGain;

	private double[] band; // the uploading rate
	
	private double noise = 1;;
	private double power_cost;
	private double collected; // the volume of the collected data
	
	
	public Objectt(int id, double transPower, double channelGain, double power_cost, Node[] nodes) { // id, update_size, compR, instantiation delay, locations
		this.id = id;
		//this.update_size = update_size;
		//this.update_interval = update_interval;
		this.transPower = transPower;
		this.channelGain = channelGain;
		
		this.band = new double[nodes.length];
		
		for (int i = 0; i < this.band.length; i++) {
			double Bj = nodes[i].getBandwidth();
			double Lj = nodes[i].getBand_cap();
			double x = 1 + (transPower * channelGain / noise);
			this.band[i] = Bj / Lj * Math.log(x) / Math.log(2);
		}
		
		this.power_cost = power_cost;
		this.collected = 0;
		//this.inst_delay = inst_delay;
		//this.locations = locations.clone();
		//this.retri = -1;
	}
	
	public Objectt(Objectt o) { // id, update_size, compR, instantiation delay, locations
		this.id = o.id;
		//this.update_size = o.update_size;
		//this.update_interval = update_interval;
		this.band = o.band.clone();
		this.transPower = o.transPower;
		this.channelGain = o.channelGain;
		this.power_cost = o.power_cost;
		this.collected += o.collected;
		//this.inst_delay = o.inst_delay;
		//this.locations = o.locations.clone();
		//this.retri = o.retri;
	}
	
	public int getID() {
		return this.id;
	}
	
	//public double getUpdate_size() {
	//	return this.update_size;
	//}
	
	//public int getUpdate_interval() {
	//	return this.update_interval;
	//}
	
	public double[] getBand() {
		return this.band;
	}
	
	public double getCollected() {
		return this.collected;
	}
	
	public double getTransPower() {
		return this.transPower;
	}
	
	public double getChannelGain() {
		return this.channelGain;
	}
	
	public double getPower_cost() {
		return this.power_cost;
	}
	
	public void add(DT d) {
		this.collected += d.getRaw_size();
	}
	
	
	public void clear() {
		this.collected = 0;
	}
	
	//public double getInst_delay() {
	//	return this.inst_delay;
	//}
	
	//public int[] getLocations() {
	//	return this.locations;
	//}
	
	//public int getRetri() {
	//	return this.retri;
	//}
	
	//public void SetRetri(int i) {
	//	this.retri = i;
	//}
}

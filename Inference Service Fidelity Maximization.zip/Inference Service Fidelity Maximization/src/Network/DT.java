package Network;

public class DT {
	private int id;
	private double consump;
	private int[] loc; //int[] loc is the mobility profile of the object of this DT, the probability is the average
	private double raw_size; // the size of the raw data from its object
	private double worker_size; // the size of the processed data from its worker digital twin
	private double proc_rate; 
	//private double threshold; // the size of the processed data from its worker digital twin
	
	public DT (int id, double consump, int[] loc, double raw_size, double worker_size, double proc_rate){
		this.id = id;
		this.consump = consump;
		//this.interval = interval;
		this.loc = loc.clone();
		this.raw_size = raw_size;
		this.worker_size = worker_size;
		//this.threshold = threshold;
		this.proc_rate = proc_rate;
		
	}
	
	public DT (DT v){
		this.id = v.getId();
		this.consump = v.getConsump();
		//this.interval = v.getInterval();
		this.loc = v.getLoc();
		this.raw_size = v.getRaw_size();
		this.worker_size = v.getWorker_size();
		//this.threshold = v.threshold;
		this.proc_rate = proc_rate;
	}
	
	public int getId() {
		return this.id;
	}
	
	public double getConsump() {
		return this.consump;
	}
	
	//public double getInterval() {
	//	return this.interval;
	//}
	
	public int[] getLoc() {
		return this.loc;
	}
	
	public double getRaw_size() {
		return this.raw_size;
	}
	
	public double getWorker_size() {
		return this.worker_size;
	}
	
	public double getProc_rate() {
		return this.proc_rate;
	}
	
	//public double getThreshold() {
	//	return this.threshold;
	//}
	
	public void setDT(DT v) {
		this.id = v.getId();
		this.consump = v.getConsump();
		//this.interval = v.getInterval();
		this.loc = v.getLoc();
		this.raw_size = v.getRaw_size();
		this.worker_size = v.getWorker_size();
		//this.threshold = v.getThreshold();
	}
}


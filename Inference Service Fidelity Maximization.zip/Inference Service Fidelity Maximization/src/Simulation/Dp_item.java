package Simulation;
import java.util.HashSet;
import java.util.Iterator;

public class Dp_item {
	private double value;
	private boolean[] itemIDs;
	
	public Dp_item (int n) {
		this.value = 0;
		this.itemIDs = new boolean[n];
		for (int i = 0; i < n; i++) {
			this.itemIDs[i] = false;
		}
	}
	
	public void setValue(double v) {
		this.value = v;
	}
	
	public void addItem (int id) {
		this.itemIDs[id] = true;;
	}
	
	public double getValue() {
		return this.value;
	}
	
	public boolean[] getSet(){
		return this.itemIDs;
	}
	
	public void setSet(boolean[] s){
        for (int i = 0; i < s.length; i++) {
        	this.itemIDs[i] = s[i];
        }
	}
	
	public void copy(Dp_item di) {
		this.setValue(di.getValue());
		this.setSet(di.getSet());
	}

}

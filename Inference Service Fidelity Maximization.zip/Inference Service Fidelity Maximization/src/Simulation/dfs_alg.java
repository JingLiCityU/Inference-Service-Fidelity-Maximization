package Simulation;

import java.util.List;
import java.util.ArrayList;

public class dfs_alg {

	public int count;

	public ArrayList<ArrayList<Integer>> allPaths = new ArrayList<ArrayList<Integer>>();
	
	//public ArrayList<ArrayList<Integer>> test = new ArrayList<ArrayList<Integer>>();
	

	private void dfs_rec(ArrayList<ArrayList<Integer>> adjLists, boolean[] visited, int v, int d,
			ArrayList<Integer> path) {
		if (this.count == 2) {
			return;
		}
		visited[v] = true;
		path.add(v);
		if (v == d) {
			this.allPaths.add(new ArrayList<Integer>());
			for (int i = 0; i < path.size(); i++) {
				this.allPaths.get(count).add(path.get(i));
				//System.out.print(path.get(i)+",");
			}
			//System.out.println("");
			this.count += 1;
		}
		else {
			for (int w : adjLists.get(v)) {
				if (!visited[w]) {
					dfs_rec(adjLists, visited, w, d, path);
				}
			}
		}
		path.remove(path.size() - 1);
		visited[v] = false;
	}

	public void dfs(ArrayList<ArrayList<Integer>> adjLists, int s, int d) {
		int n = adjLists.size();
		boolean[] visited = new boolean[n];

		ArrayList<Integer>path = new ArrayList<Integer>();

		dfs_rec(adjLists, visited, s, d, path);
	}

	public ArrayList<ArrayList<Integer>> getAllPaths (double[][] map, int start, int end) {

		ArrayList<ArrayList<Integer>> adjLists = new ArrayList<ArrayList<Integer>>();
		final int n = map.length;

		count = 0;

		for (int v = 0; v < n; v++) {
			adjLists.add(new ArrayList<Integer>());
		}

		for (int i=0; i < map.length; i++) {
			for (int j =0; j < map.length; j++) {
				if (map[i][j] != -1) {
					adjLists.get(i).add(j);
				}
			}
		}
		dfs(adjLists, start, end);
		//System.out.println(this.allPaths);
		//System.out.println("***"+test);

		return this.allPaths;
	}
}
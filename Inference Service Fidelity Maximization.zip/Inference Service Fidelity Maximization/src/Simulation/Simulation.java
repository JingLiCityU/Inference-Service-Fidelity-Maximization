package Simulation;


import ilog.concert.*;
import ilog.cplex.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Network.*;

public class Simulation {
	static final double M = -1;

	//private static int Sources_size = 4; // 4- 8


	private static int large = 999999;

	private static int Node_size = 100;


	private static int IoT_size = 2000; // 2000

	private static int model_size = 500; // users

	private static int Time_num = 20; // 20


	//private static double time_duration = 50/ 1000; //50ms per time slot, i.e., 0.05 s  ***************
	//private static double time_duration = 50; //50ms per time slot, i.e., 0.05 s 


	private static double omega = 0.1;

	private static double dishu = 1.1;
	private static double bei = 10;

	private static double instantiation_ratio = 0.01;

	private static double migration_ratio = 0.1;
	//private static double beta_s = 3;

	//private static double alpha = 8;
	private static double beta = 4;


	//private static double LB_u = 0.1; // the lower bound of 

	//private static double alp = 4;//alpha


	//private static double min_cost = 0.02;

	private static Node[] Nodes = new Node [Node_size];
	//private static Request[] Requests = new Request [Requests_size];

	//private static double [][] connect_map = new double [Node_size][Node_size] ;

	//private static double [][] cost_map = new double [Node_size][Node_size] ;


	private static List<String> getMatch(String lineTxt) {
		Pattern p = Pattern.compile("(?<=n\\()[^\\)]+"); 
		Matcher m = p.matcher(lineTxt);
		List<String> result = new ArrayList<String>();
		while(m.find()){
			if (m.group().equals("$i")) {
				break;
			}
			result.add(m.group());
		}
		return result;
	}


	public static double[][] readTxtFileIntoStringArrList(String filePath, int n){
		double[][] map = new double[n][n];
		for (int i = 0; i <n ; i++) {
			for (int j = 0; j <n; j++){
				if (i==j) {
					map[i][j] = 0;
				}
				else {
					map[i][j] = M;//
				}
			}
		}
		int num = 0;
		List<String> list = new ArrayList<String>();
		try
		{
			String encoding = "GBK";
			File file = new File(filePath);
			if (file.isFile() && file.exists())
			{ // �ж��ļ��Ƿ����
				InputStreamReader read = new InputStreamReader(
						new FileInputStream(file), encoding);// ���ǵ������ʽ
				BufferedReader bufferedReader = new BufferedReader(read);
				String lineTxt = null;

				while ((lineTxt = bufferedReader.readLine()) != null){
					list = getMatch(lineTxt);
					if (list.size()!=0) {
						num += 1;
						int x = Integer.valueOf(list.get(0)) ;
						int y = Integer.valueOf(list.get(1)) ;
						map[x][y] = 1;
						map[y][x] = 1;
					}
				}
				bufferedReader.close();
				read.close();
			}
			else
			{
				System.out.println("The network document cannot be found"); //�Ҳ���ָ�����ļ�
			}
		}
		catch (Exception e)
		{
			System.out.println("There is an error when reading the network document"); //��ȡ�ļ����ݳ���
			e.printStackTrace();
		}
		//System.out.println (Arrays.deepToString(map));
		//System.out.println(num);

		//System.out.println(num);

		return map;
	}



	static double max(double a, double b) 
	{ 
		return (a > b) ? a : b; 
	} 

	static int max(int a, int b) 
	{ 
		return (a > b) ? a : b; 
	} 


	static double cal_U(double a, Objectt o) {
		double collected = o.getCollected();
		double value1 = Math.log((a + collected)/bei + 1) / Math.log(dishu);
		double value2 = Math.log(collected/bei + 1) / Math.log(dishu);
		return value1 - value2;
	}

	static void clear(Node[] Nodes) { 
		for (int i = 0; i < Nodes.length; i++ ) {
			Nodes[i].clear();
		}
	} 

	static void clear(Objectt[] IoTs) { 
		for (int i = 0; i < IoTs.length; i++ ) {
			IoTs[i].clear();
		}
	}

	static void clear_band(Node[] Nodes) { 
		for (int i = 0; i < Nodes.length; i++ ) {
			Nodes[i].clear_band();
		}
	}

	static void clear(Request[] Rs) { 
		for (int i = 0; i < Rs.length; i++ ) {
			Rs[i].clear();
		}
	} 


	static double getRandomValue(double a, double b) {
		double addon = (b - a) * Math.random(); 
		return a + addon;
	} 
	
	static int getRandomIntValue(int a, int b) {
		return a + (int)(Math.random() * (b-a+1));
	} 
	

	private static shortestPath dijkstra_alg(int orig, double [][] map) {
		int n =map.length;       //����ĸ���
		double[] shortest = new double[n];  //��Ŵ�start�������ڵ�����·��
		boolean[] visited = new boolean[n]; //��ǵ�ǰ�ö�������·���Ƿ��Ѿ������true��ʾ�Ѿ����

		/*for(int i=0;i<n;i++) {
			System.out.print(map[orig][i] + ", "); 
		}
		System.out.println();
		System.out.println("*************");*/

		// TODO Auto-generated method stub
		// ��ʼ������һ���������
		shortest[orig] = 0;
		visited[orig] = true;

		//��Ŵ�start���������ڵ�����·��
		String[] path = new String[n];
		for(int i = 0; i < n; i++){
			path[i] = new String(orig + "," + i);
		}
		for(int count = 0; count != n-1; count ++)
		{
			//ѡ��һ�������ʼ���������Ϊ��Ƕ���
			int k = (int)M;
			double min = M;
			for(int i =0; i< n ; i++)//����ÿһ������
			{
				if( !visited[i] && map[orig][i] != M) //����ö���δ������������orig����
				{
					if(min == -1 || min > map[orig][i]) //�ҵ���orig����ĵ�
					{
						min = map[orig][i];
						k = i;
					}
				}
			}
			//��ȷ��ͼ���ɵľ��󲻿��ܳ���K== M�����
			if(k == (int)M)
			{
				return new shortestPath(path, map[orig]);
			}
			shortest[k] = min;
			visited[k] = true;
			//��kΪ���ĵ㣬����oirg��δ���ʵ�ľ���
			for (int i = 0; i < n; i++)
			{
				if (!visited[i] && map[k][i] != M)
				{
					double callen = min + map[k][i];
					if (map[orig][i] == M || map[orig][i] > callen)
					{
						map[orig][i] = callen;
						path[i] = path[k] + "," + i ;
					}
				}
			}
		}

		//for(int i=0;i<n;i++)  
		//	System.out.println("��"+orig+"������"+i+"�����·��Ϊ��"+path[i]);    
		//System.out.println("=====================================");


		/*for(int i=0;i<n;i++) {
			System.out.print(map[orig][i] + ", "); 
		}
		System.out.println();*/


		return new shortestPath(path, map[orig]);
	}


	public static int[] assignIoT (int t, int[] assign_DT, int[] assign_m, double[][] shortestD_map, double[][] connect_map_t, double[][] cost_map_t, Node[] Nodes_t, Objectt[] IoTs_t, DT [] DTs_t, model [] models_t) {

		clear(Nodes_t);
		clear(IoTs_t);

		double[][] obj = new double[IoTs_t.length][Nodes_t.length];
		for (int i = 0; i < IoTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
				obj[i][j] = 0;
				for (int m = 0; m < models_t.length; m++) {
					int [] m_DTs_index = models_t[m].getDTs();
					int K = m_DTs_index.length;
					for (int k = 0; k < K; k++) {
						if (m_DTs_index[k] == i) {
							obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]) / K;
							//obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]);
						}
					}
				}
				//System.out.println(obj[i][j]);
			}
		}


		//for (int i = 0; i < IoTs_t.length; i++) {
		//	for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
		//		System.out.println(obj[i][j]);
		//	}
		//}


		for (int i = 0; i < IoTs_t.length; i++) {
			int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
			int K = loc.length;
			int loc_k = loc[t%K]; // the location of the IoT device at time t
			for (int j = 0; j < Nodes_t.length; j ++) {
				if (loc_k == j || connect_map_t[loc_k][j] == 1) {
					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[j];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[j][assign_DT[i]];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[assign_DT[i]].getProc_cost();
					double c_m_trans = 0;
					double c_m_proc = 0;
					for (int m = 0; m < models_t.length; m++) {
						int [] m_DTs_index = models_t[m].getDTs();
						int KK = m_DTs_index.length;
						for (int k = 0; k < KK; k++) {
							if (m_DTs_index[k] == i) {
								c_m_trans += DTs_t[i].getWorker_size() * shortestD_map[assign_DT[i]][assign_m[m]];
								c_m_proc += DTs_t[i].getWorker_size() * Nodes_t[assign_m[m]].getProc_cost();
							}
						}
					}
					obj[i][j] -= omega * (c_upload + c_trans + c_DT_proc + c_m_trans + c_m_proc);

				}
				else {
					obj[i][j] = 0;
				}
			}
		}

		//double [][] h_table = new double [N] [Nodes_t.length]; 
		double [][] ratio_table = new double [IoTs_t.length] [Nodes_t.length]; 
		// the utility gain table, i.e., the profit table

		for (int n = 0; n < IoTs_t.length; n++) { // for each worker DT //build the tables
			for (int v = 0; v < Nodes_t.length; v++) { // for each possible placement of worker DT
				//ratio_table[n][v] = obj[n][v] / (IoTs_t[n].getBand()[v] / Nodes_t[v].getBand_cap());
				ratio_table[n][v] = obj[n][v];
			}

		}

		int [] assign_IoT = new int [IoTs_t.length];
		for (int i = 0; i< assign_IoT.length; i++) {
			assign_IoT[i] = -1;
		}


		//System.out.println("length of IoT devices: " + IoTs_t.length);

		int count = 0;
		for (int i = 0; i < assign_IoT.length; i++) {

			double max_ratio = 0; // the placement of DT with the maximum ratio of utility/consumed resource
			int max_o_index = -1; // the index of the worker DT
			int max_v_index = -1; // the assigned cloudlet

			for (int j = 0; j < assign_IoT.length; j++) {
				if (assign_IoT[j] == -1) {//DT j has not been assigned to any cloudlet
					for (int v = 0; v < Nodes_t.length; v++) {
						if (Nodes_t[v].enough_band(IoTs_t[j]) && ratio_table[j][v] > max_ratio) {
							max_ratio = ratio_table[j][v];
							max_o_index = j;
							max_v_index = v;
						}
					}
				}
			}

			if (max_o_index != -1) { 

				count ++;
				assign_IoT[max_o_index] = max_v_index;
				Nodes_t[max_v_index].put(IoTs_t[max_o_index]);
				IoTs_t[max_o_index].add(DTs_t[max_o_index]);
			}
		}
		return assign_IoT;
	}


	static double knapSack(int W, int wt[], double val[], int n) 
	{ 
		int i, w; 
		double K[][] = new double[n + 1][W + 1]; 

		// Build table K[][] in bottom up manner 
		for (i = 0; i <= n; i++) { 
			for (w = 0; w <= W; w++) { 
				if (i == 0 || w == 0) 
					K[i][w] = 0; 
				else if (wt[i - 1] <= w) 
					K[i][w] = max( 
							val[i - 1] + K[i - 1][w - wt[i - 1]], 
							K[i - 1][w]); 
				else
					K[i][w] = K[i - 1][w]; 
			} 
		} 

		return K[n][W]; 
	} 


	public static Dp_item knapSack(int W, int wt[], double val[]) { 
		int i, w; 
		int n = val.length;
		Dp_item K[][] = new Dp_item[n + 1][W + 1]; 

		for (i = 0; i <= n; i++) { 
			for (w = 0; w <= W; w++) { 
				K[i][w] = new Dp_item(i);
			}
		}

		// Build table K[][] in bottom up manner 
		for (i = 0; i <= n; i++) { 
			for (w = 0; w <= W; w++) { 
				if (i == 0 || w == 0) {
					K[i][w].setValue(0);
				}
				else if (wt[i - 1] <= w) 
					if (val[i - 1] + K[i - 1][w - wt[i - 1]].getValue() > K[i - 1][w].getValue()) {
						K[i][w].setSet(K[i-1][w - wt[i - 1]].getSet());
						K[i][w].addItem(i-1);
						K[i][w].setValue(val[i - 1] + K[i - 1][w - wt[i - 1]].getValue());
					}
					else {
						K[i][w].copy(K[i - 1][w]);
					}
				else
					K[i][w].copy(K[i - 1][w]); 
			} 
		} 

		return K[n][W]; 
	} 


	public static int[] GAP (int W[], int wt[], double val[][]) { // modified
		int M = W.length; // number of bins
		int N = wt.length; // number of items

		int[] assign = new int[N];


		for (int i = 0; i< N; i++) {
			assign[i] = -1;
		}

		for (int j =0; j < M; j++) {
			double[] p_val = new double [N];
			for (int i = 0; i< N; i++) {
				if (assign[i] == -1) {
					p_val[i] = val[i][j];
				}
				else {
					p_val[i] = val[i][j] - val[i][assign[i]];
				}
			}

			//double ii= knapSack(W[j], wt, p_val, wt.length);

			boolean[] knapResult = knapSack(W[j], wt, p_val).getSet();

			for (int i = 0; i < knapResult.length; i++) {
				if (knapResult[i] == true)
					assign[i] = j;
			}
		}
		return assign;
	}


	public static res alg01(double[][] connect_map_t, double[][] cost_map_t, Node[] Nodes_t, Objectt[] IoTs_t, DT [] DTs_t, model [] models_t) {

		long startTime = System.currentTimeMillis();
		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		double tot_u = 0;

		double [][] shortestD_map = new double[cost_map_t.length][cost_map_t[0].length];

		for (int i = 0; i< cost_map_t.length; i++) { //print shortest delay
			shortestD_map[i] = dijkstra_alg(i, cost_map_t).getValue();
		}

		double[][] c_DT_exp = new double [DTs_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_DT_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {

				c_DT_exp[i][j] += DTs_t[i].getConsump() * instantiation_ratio;

				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				for (int k = 0; k < K; k++) {
					int loc_k = loc[k];
					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[loc_k];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[loc_k][j];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[j].getProc_cost();
					c_DT_exp[i][j] += (c_upload + c_trans + c_DT_proc) / K;
				}
			}
		}

		int [] assign_DT = new int [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			assign_DT[i] = -1;
		}

		boolean[] admission_DT = new boolean [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			admission_DT[i] = false; // initially all DTs are not admitted;
		}

		//int u_count = Rs.length /  Nodes_t.length;
		//int count = 0;

		System.out.println("begin to place DTs");

		boolean flag = true;
		while (flag) {

			//System.out.println(count);

			int index = max(DTs_t.length,Nodes_t.length);

			double[][] c_DT_exp_t = new double [index][index]; // cost of offloading k to v
			//System.out.println(c_x_t.length);

			//int ccc = 0;
			for (int i = 0; i < c_DT_exp_t.length; i++) { // requests
				if (i < DTs_t.length) {
					for (int j = 0; j < c_DT_exp_t[0].length; j++) { // cloudlets
						if (admission_DT[i] == false) { // the request i has not been admitted
							if (j < Nodes_t.length) {
								if (Nodes_t[j].enough(DTs_t[i]) == false) {
									c_DT_exp_t[i][j] = large;
									//System.out.println( "!");
								}
								else{
									c_DT_exp_t[i][j] = (int)(c_DT_exp[i][j]*100);
									//System.out.println(c_DT_exp_t[i][j]);
									//c_x_t[i][j] = c_x[i][j] ;
								}
								//c_x_t[i][j] = (int)c_x[i + count * Nodes_t.length][j] ; // int ��double��
								//Random random = new Random();
								//double d = Math.random();
								//System.out.println(d);
								//c_x_t[i][j] = c_x[i + count * Nodes_t.length][j] ;
								//c_x_t[i][j] = d;
								//if (j != c_x_t[0].length-1)
								//	System.out.print( c_x_t[i][j] + ", ");
								//else
								//	System.out.print( c_x_t[i][j] + "}, ");
							}
							else {
								c_DT_exp_t[i][j] = large;  //j >= Nodes_t.length, virtual cloudlet nodes
							}

						}
						else {// the request i has been admitted
							c_DT_exp_t[i][j] = large;
						}
					}
				}
				else {
					for (int j = 0; j < c_DT_exp_t[0].length; j++) {
						c_DT_exp_t[i][j] = large;	
					}
				}

				//System.out.println();
			}

			//System.out.println(c_x_t.length);
			//System.out.println(c_x_t[0].length);


			KM kkmm = new KM (c_DT_exp_t);

			//System.out.println( "**********");

			int[] match = kkmm.getMatch(-1); // index: cloudlet, value: request //���ڼ�¼���ս���ж���yƥ��Ķ���x
			//System.out.println("*****************");
			//System.out.println(match.length);
			//System.out.println( "**********");

			int count = 0; //count the number of admitted requests in this round

			for (int i = 0; i < Nodes_t.length; i++) { //
				//System.out.println(match[i]);
				//if ((int)c_x_t[match[i]][i] != (int) large) { // i : cloudlet, match[i] : request
				if (admission_DT[match[i]] == false) { // request match[i] is not admitted

					tot_u += c_DT_exp[match[i]][i];

					//cost += c_x[match[i]][i];
					Nodes_t[i].put(DTs_t[match[i]]);

					assign_DT[match[i]] = i;

					admission_DT[match[i]] = true; // request match[i] now is admitted
					count ++;	
				}
				//}
				//else
			}
			//count ++;

			flag = false;
			for (int i = 0; i < admission_DT.length; i++) {
				if (admission_DT[i] == false) { // if it exists one request not admitted, it will keep looping
					flag = true;
					break;
				}
			}
			//System.out.println("<<<<<<<<<<<<<<");
			//System.out.println(count);

			if (count == 0) {
				break;
			}
		}



		System.out.println("begin to place models");
		////////////////////////// 
		// Place models

		double[][] c_m_exp = new double [models_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < models_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_m_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < models_t.length; i++) {
			int [] m_DTs_index = models_t[i].getDTs();

			for (int j = 0; j < Nodes_t.length; j++) {

				c_m_exp[i][j] += models_t[i].getConsump() * instantiation_ratio;

				for (int k = 0; k < m_DTs_index.length; k++) {
					int DT_index = m_DTs_index[k];
					int loc_k = assign_DT[DT_index];
					double c_trans = DTs_t[DT_index].getWorker_size() * shortestD_map[loc_k][j];
					c_m_exp[i][j] += c_trans;
					double c_m_proc = DTs_t[DT_index].getWorker_size() * Nodes_t[j].getProc_cost();
					c_m_exp[i][j] += c_m_proc;
				}
			}
		}

		int [] assign_m = new int [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			assign_m[i] = -1;
		}

		boolean[] admission_m = new boolean [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			admission_m[i] = false; // initially all DTs are not admitted;
		}

		boolean flag_m = true;
		while (flag_m) {

			int index = max(models_t.length,Nodes_t.length);

			double[][] c_m_exp_t = new double [index][index]; // cost of offloading k to v
			//System.out.println(c_x_t.length);

			//int ccc = 0;
			for (int i = 0; i < c_m_exp_t.length; i++) { // requests
				if (i < models_t.length) {
					for (int j = 0; j < c_m_exp_t[0].length; j++) { // cloudlets
						if (admission_m[i] == false) { // the request i has not been admitted
							if (j < Nodes_t.length) {
								if (Nodes_t[j].enough(models_t[i]) == false) {
									c_m_exp_t[i][j] = large;
									//System.out.println( "!");
								}
								else{
									c_m_exp_t[i][j] = (int) (c_m_exp[i][j]*100);
									//System.out.println(c_m_exp_t[i][j]);
									//c_x_t[i][j] = c_x[i][j] ;
								}
								//c_x_t[i][j] = (int)c_x[i + count * Nodes_t.length][j] ; // int ��double��
								//Random random = new Random();
								//double d = Math.random();
								//System.out.println(d);
								//c_x_t[i][j] = c_x[i + count * Nodes_t.length][j] ;
								//c_x_t[i][j] = d;
								//if (j != c_x_t[0].length-1)
								//	System.out.print( c_x_t[i][j] + ", ");
								//else
								//	System.out.print( c_x_t[i][j] + "}, ");
							}
							else {
								c_m_exp_t[i][j] = large;  //j >= Nodes_t.length, virtual cloudlet nodes
							}

						}
						else {// the request i has been admitted
							c_m_exp_t[i][j] = large;
						}
					}
				}
				else {
					for (int j = 0; j < c_m_exp_t[0].length; j++) {
						c_m_exp_t[i][j] = large;	
					}
				}
				//System.out.println();
			}

			KM kkmm = new KM (c_m_exp_t);

			//System.out.println( "**********");

			int[] match = kkmm.getMatch(-1); // index: cloudlet, value: request //���ڼ�¼���ս���ж���yƥ��Ķ���x
			//System.out.println("*****************");
			//System.out.println(match.length);
			//System.out.println( "**********");

			int count = 0; //count the number of admitted requests in this round

			for (int i = 0; i < Nodes_t.length; i++) { //
				//System.out.println(match[i]);
				//if ((int)c_x_t[match[i]][i] != (int) large) { // i : cloudlet, match[i] : request


				if (admission_m[match[i]] == false) { // request match[i] is not admitted
					//cost += c_x[match[i]][i];


					tot_u += c_m_exp[match[i]][i];

					Nodes_t[i].put(models_t[match[i]]);

					assign_m[match[i]] = i;

					admission_m[match[i]] = true; // request match[i] now is admitted
					count ++;
				}
				//}
				//else
			}

			//count ++;

			flag_m = false;
			for (int i = 0; i < admission_m.length; i++) {
				if (admission_m[i] == false) { // if it exists one request not admitted, it will keep looping
					flag_m = true;
					break;
				}
			}
			//System.out.println("<<<<<<<<<<<<<<");
			//System.out.println(count);

			if (count == 0) {
				break;
			}
		}


		clear(Nodes_t);
		clear(IoTs_t);

		long endTime = System.currentTimeMillis();

		res result= new res (tot_u, endTime -startTime);

		return result;


		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		//for (int i = 0; i < used.length; i++) {
		//	System.out.println("cloudlet " + i +": residual: " + used[i] + ", capacity: " + Nodes_t[i].getCapacity() );
		//}
	}



	public static res alg02(double[][] connect_map_t, double[][] cost_map_t, Node[] Nodes_t, Objectt[] IoTs_t, DT [] DTs_t, model [] models_t) {

		long startTime = System.currentTimeMillis();
		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		double tot_u = 0;

		double [][] shortestD_map = new double[cost_map_t.length][cost_map_t[0].length];

		for (int i = 0; i< cost_map_t.length; i++) { //print shortest delay
			shortestD_map[i] = dijkstra_alg(i, cost_map_t).getValue();
		}

		double[][] c_DT_exp = new double [DTs_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_DT_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_DT_exp[i][j] += DTs_t[i].getConsump() * instantiation_ratio;
				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				for (int k = 0; k < K; k++) {
					int loc_k = loc[k];
					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[loc_k];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[loc_k][j];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[j].getProc_cost();
					c_DT_exp[i][j] += (c_upload + c_trans + c_DT_proc) / K;
				}
			}
		}

		int [] assign_DT = new int [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			assign_DT[i] = -1;
		}

		boolean[] admission_DT = new boolean [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			admission_DT[i] = false; // initially all DTs are not admitted;
		}

		//int u_count = Rs.length /  Nodes_t.length;
		//int count = 0;

		System.out.println("begin to place DTs");

		boolean flag = true;
		while (flag) {

			//System.out.println(count);

			int index = max(DTs_t.length,Nodes_t.length);

			double[][] c_DT_exp_t = new double [index][index]; // cost of offloading k to v
			//System.out.println(c_x_t.length);

			//int ccc = 0;
			for (int i = 0; i < c_DT_exp_t.length; i++) { // requests
				if (i < DTs_t.length) {
					for (int j = 0; j < c_DT_exp_t[0].length; j++) { // cloudlets
						if (admission_DT[i] == false) { // the request i has not been admitted
							if (j < Nodes_t.length) {
								if (Nodes_t[j].enough(DTs_t[i]) == false) {
									c_DT_exp_t[i][j] = large;
									//System.out.println( "!");
								}
								else{
									c_DT_exp_t[i][j] = (int)(c_DT_exp[i][j]*100);
									//System.out.println(c_DT_exp_t[i][j]);
									//c_x_t[i][j] = c_x[i][j] ;
								}
								//c_x_t[i][j] = (int)c_x[i + count * Nodes_t.length][j] ; // int ��double��
								//Random random = new Random();
								//double d = Math.random();
								//System.out.println(d);
								//c_x_t[i][j] = c_x[i + count * Nodes_t.length][j] ;
								//c_x_t[i][j] = d;
								//if (j != c_x_t[0].length-1)
								//	System.out.print( c_x_t[i][j] + ", ");
								//else
								//	System.out.print( c_x_t[i][j] + "}, ");
							}
							else {
								c_DT_exp_t[i][j] = large;  //j >= Nodes_t.length, virtual cloudlet nodes
							}

						}
						else {// the request i has been admitted
							c_DT_exp_t[i][j] = large;
						}
					}
				}
				else {
					for (int j = 0; j < c_DT_exp_t[0].length; j++) {
						c_DT_exp_t[i][j] = large;	
					}
				}

				//System.out.println();
			}

			//System.out.println(c_x_t.length);
			//System.out.println(c_x_t[0].length);


			KM kkmm = new KM (c_DT_exp_t);

			//System.out.println( "**********");

			int[] match = kkmm.getMatch(-1); // index: cloudlet, value: request //���ڼ�¼���ս���ж���yƥ��Ķ���x
			//System.out.println("*****************");
			//System.out.println(match.length);
			//System.out.println( "**********");

			int count = 0; //count the number of admitted requests in this round

			for (int i = 0; i < Nodes_t.length; i++) { //
				//System.out.println(match[i]);
				//if ((int)c_x_t[match[i]][i] != (int) large) { // i : cloudlet, match[i] : request
				if (admission_DT[match[i]] == false) { // request match[i] is not admitted
					//cost += c_x[match[i]][i];
					Nodes_t[i].put(DTs_t[match[i]]);

					assign_DT[match[i]] = i;

					admission_DT[match[i]] = true; // request match[i] now is admitted
					count ++;	
				}
				//}
				//else
			}
			//count ++;

			flag = false;
			for (int i = 0; i < admission_DT.length; i++) {
				if (admission_DT[i] == false) { // if it exists one request not admitted, it will keep looping
					flag = true;
					break;
				}
			}
			//System.out.println("<<<<<<<<<<<<<<");
			//System.out.println(count);

			if (count == 0) {
				break;
			}
		}



		System.out.println("begin to place models");
		////////////////////////// 
		// Place models

		double[][] c_m_exp = new double [models_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < models_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_m_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < models_t.length; i++) {
			int [] m_DTs_index = models_t[i].getDTs();

			for (int j = 0; j < Nodes_t.length; j++) {

				c_m_exp[i][j] += models_t[i].getConsump() * instantiation_ratio;

				for (int k = 0; k < m_DTs_index.length; k++) {
					int DT_index = m_DTs_index[k];
					int loc_k = assign_DT[DT_index];
					double c_trans = DTs_t[DT_index].getWorker_size() * shortestD_map[loc_k][j];
					c_m_exp[i][j] += c_trans;
					double c_m_proc = DTs_t[DT_index].getWorker_size() * Nodes_t[j].getProc_cost();
					c_m_exp[i][j] += c_m_proc;
				}
			}
		}

		int [] assign_m = new int [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			assign_m[i] = -1;
		}

		boolean[] admission_m = new boolean [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			admission_m[i] = false; // initially all DTs are not admitted;
		}

		boolean flag_m = true;
		while (flag_m) {

			int index = max(models_t.length,Nodes_t.length);

			double[][] c_m_exp_t = new double [index][index]; // cost of offloading k to v
			//System.out.println(c_x_t.length);

			//int ccc = 0;
			for (int i = 0; i < c_m_exp_t.length; i++) { // requests
				if (i < models_t.length) {
					for (int j = 0; j < c_m_exp_t[0].length; j++) { // cloudlets
						if (admission_m[i] == false) { // the request i has not been admitted
							if (j < Nodes_t.length) {
								if (Nodes_t[j].enough(models_t[i]) == false) {
									c_m_exp_t[i][j] = large;
									//System.out.println( "!");
								}
								else{
									c_m_exp_t[i][j] = (int) (c_m_exp[i][j]*100);
									//System.out.println(c_m_exp_t[i][j]);
									//c_x_t[i][j] = c_x[i][j] ;
								}
								//c_x_t[i][j] = (int)c_x[i + count * Nodes_t.length][j] ; // int ��double��
								//Random random = new Random();
								//double d = Math.random();
								//System.out.println(d);
								//c_x_t[i][j] = c_x[i + count * Nodes_t.length][j] ;
								//c_x_t[i][j] = d;
								//if (j != c_x_t[0].length-1)
								//	System.out.print( c_x_t[i][j] + ", ");
								//else
								//	System.out.print( c_x_t[i][j] + "}, ");
							}
							else {
								c_m_exp_t[i][j] = large;  //j >= Nodes_t.length, virtual cloudlet nodes
							}

						}
						else {// the request i has been admitted
							c_m_exp_t[i][j] = large;
						}
					}
				}
				else {
					for (int j = 0; j < c_m_exp_t[0].length; j++) {
						c_m_exp_t[i][j] = large;	
					}
				}
				//System.out.println();
			}

			KM kkmm = new KM (c_m_exp_t);

			//System.out.println( "**********");

			int[] match = kkmm.getMatch(-1); // index: cloudlet, value: request //���ڼ�¼���ս���ж���yƥ��Ķ���x
			//System.out.println("*****************");
			//System.out.println(match.length);
			//System.out.println( "**********");

			int count = 0; //count the number of admitted requests in this round

			for (int i = 0; i < Nodes_t.length; i++) { //
				//System.out.println(match[i]);
				//if ((int)c_x_t[match[i]][i] != (int) large) { // i : cloudlet, match[i] : request


				if (admission_m[match[i]] == false) { // request match[i] is not admitted
					//cost += c_x[match[i]][i];
					Nodes_t[i].put(models_t[match[i]]);

					assign_m[match[i]] = i;

					admission_m[match[i]] = true; // request match[i] now is admitted
					count ++;
				}
				//}
				//else
			}

			//count ++;

			flag_m = false;
			for (int i = 0; i < admission_m.length; i++) {
				if (admission_m[i] == false) { // if it exists one request not admitted, it will keep looping
					flag_m = true;
					break;
				}
			}
			//System.out.println("<<<<<<<<<<<<<<");
			//System.out.println(count);

			if (count == 0) {
				break;
			}
		}


		for (int t = 0; t < Time_num; t++){

			//int[] IoT_loc = new int [IoTs_t.length]; 

			// initialize the profit table
			double[][] obj = new double[IoTs_t.length][Nodes_t.length];
			for (int i = 0; i < IoTs_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
					obj[i][j] = 0;
					for (int m = 0; m < models_t.length; m++) {
						int [] m_DTs_index = models_t[m].getDTs();
						int K = m_DTs_index.length;
						for (int k = 0; k < K; k++) {
							if (m_DTs_index[k] == i) {
								obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]) / K;
								//obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]);
							}
						}
					}
					//System.out.println(obj[i][j]);
				}
			}

			//for (int i = 0; i < IoTs_t.length; i++) {
			//	for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
			//		System.out.println(obj[i][j]);
			//	}
			//}


			for (int i = 0; i < IoTs_t.length; i++) {
				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				int loc_k = loc[t%K]; // the location of the IoT device at time t
				for (int j = 0; j < Nodes_t.length; j ++) {
					if (loc_k == j || connect_map_t[loc_k][j] == 1) {
						double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[j];
						double c_trans = DTs_t[i].getRaw_size() * shortestD_map[j][assign_DT[i]];
						double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[assign_DT[i]].getProc_cost();
						double c_m_trans = 0;
						double c_m_proc = 0;
						for (int m = 0; m < models_t.length; m++) {
							int [] m_DTs_index = models_t[m].getDTs();
							int KK = m_DTs_index.length;
							for (int k = 0; k < KK; k++) {
								if (m_DTs_index[k] == i) {
									c_m_trans += DTs_t[i].getWorker_size() * shortestD_map[assign_DT[i]][assign_m[m]];
									c_m_proc += DTs_t[i].getWorker_size() * Nodes_t[assign_m[m]].getProc_cost();
								}
							}
						}
						obj[i][j] -= omega * (c_upload + c_trans + c_DT_proc + c_m_trans + c_m_proc);

					}
					else {
						obj[i][j] = 0;
					}
				}
			}

			//double [][] h_table = new double [N] [Nodes_t.length]; 
			double [][] ratio_table = new double [IoTs_t.length] [Nodes_t.length]; 
			// the utility gain table, i.e., the profit table

			for (int n = 0; n < IoTs_t.length; n++) { // for each worker DT //build the tables
				for (int v = 0; v < Nodes_t.length; v++) { // for each possible placement of worker DT
					//ratio_table[n][v] = obj[n][v] / (IoTs_t[n].getBand()[v] / Nodes_t[v].getBand_cap());
					ratio_table[n][v] = obj[n][v];
				}

			}

			int [] assign_IoT = new int [IoTs_t.length];
			for (int i = 0; i< assign_IoT.length; i++) {
				assign_IoT[i] = -1;
			}


			//System.out.println("length of IoT devices: " + IoTs_t.length);

			int count = 0;
			for (int i = 0; i < assign_IoT.length; i++) {

				double max_ratio = 0; // the placement of DT with the maximum ratio of utility/consumed resource
				int max_o_index = -1; // the index of the worker DT
				int max_v_index = -1; // the assigned cloudlet

				for (int j = 0; j < assign_IoT.length; j++) {
					if (assign_IoT[j] == -1) {//DT j has not been assigned to any cloudlet
						for (int v = 0; v < Nodes_t.length; v++) {
							if (Nodes_t[v].enough_band(IoTs_t[j]) && ratio_table[j][v] > max_ratio) {
								max_ratio = ratio_table[j][v];
								max_o_index = j;
								max_v_index = v;
							}
						}
					}
				}

				if (max_o_index != -1) { 

					count ++;
					assign_IoT[max_o_index] = max_v_index;
					Nodes_t[max_v_index].put(IoTs_t[max_o_index]);
					tot_u += obj[max_o_index][max_v_index];
					IoTs_t[max_o_index].add(DTs_t[max_o_index]);
				}
			}

			//System.out.println("number of admitted IoT devices: " + count);

			clear_band(Nodes_t);

			//System.out.println("time: " + t + ", u: "+ tot_u);
		}

		clear(Nodes_t);
		clear(IoTs_t);

		long endTime = System.currentTimeMillis();

		res result= new res (tot_u, endTime -startTime);

		return result;


		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		//for (int i = 0; i < used.length; i++) {
		//	System.out.println("cloudlet " + i +": residual: " + used[i] + ", capacity: " + Nodes_t[i].getCapacity() );
		//}
	}


	public static res alg03(double[][] connect_map_t, double[][] cost_map_t, Node[] Nodes_t, Objectt[] IoTs_t, DT [] DTs_t, model [] models_t) {

		long startTime = System.currentTimeMillis();
		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}
		
		double tot_u = 0;

		double [][] shortestD_map = new double[cost_map_t.length][cost_map_t[0].length];

		for (int i = 0; i< cost_map_t.length; i++) { //print shortest delay
			shortestD_map[i] = dijkstra_alg(i, cost_map_t).getValue();
		}

		double[][] c_DT_exp = new double [DTs_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_DT_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_DT_exp[i][j] += DTs_t[i].getConsump() * instantiation_ratio;
				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				for (int k = 0; k < K; k++) {
					int loc_k = loc[k];
					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[loc_k];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[loc_k][j];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[j].getProc_cost();
					c_DT_exp[i][j] += (c_upload + c_trans + c_DT_proc) / K;
				}
			}
		}

		int [] assign_DT = new int [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			assign_DT[i] = -1;
		}

		boolean[] admission_DT = new boolean [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			admission_DT[i] = false; // initially all DTs are not admitted;
		}

		//int u_count = Rs.length /  Nodes_t.length;
		//int count = 0;

		System.out.println("begin to place DTs");

		boolean flag = true;
		while (flag) {

			//System.out.println(count);

			int index = max(DTs_t.length,Nodes_t.length);

			double[][] c_DT_exp_t = new double [index][index]; // cost of offloading k to v
			//System.out.println(c_x_t.length);

			//int ccc = 0;
			for (int i = 0; i < c_DT_exp_t.length; i++) { // requests
				if (i < DTs_t.length) {
					for (int j = 0; j < c_DT_exp_t[0].length; j++) { // cloudlets
						if (admission_DT[i] == false) { // the request i has not been admitted
							if (j < Nodes_t.length) {
								if (Nodes_t[j].enough(DTs_t[i]) == false) {
									c_DT_exp_t[i][j] = large;
									//System.out.println( "!");
								}
								else{
									c_DT_exp_t[i][j] = (int)(c_DT_exp[i][j]*100);
									//System.out.println(c_DT_exp_t[i][j]);
									//c_x_t[i][j] = c_x[i][j] ;
								}
								//c_x_t[i][j] = (int)c_x[i + count * Nodes_t.length][j] ; // int ��double��
								//Random random = new Random();
								//double d = Math.random();
								//System.out.println(d);
								//c_x_t[i][j] = c_x[i + count * Nodes_t.length][j] ;
								//c_x_t[i][j] = d;
								//if (j != c_x_t[0].length-1)
								//	System.out.print( c_x_t[i][j] + ", ");
								//else
								//	System.out.print( c_x_t[i][j] + "}, ");
							}
							else {
								c_DT_exp_t[i][j] = large;  //j >= Nodes_t.length, virtual cloudlet nodes
							}

						}
						else {// the request i has been admitted
							c_DT_exp_t[i][j] = large;
						}
					}
				}
				else {
					for (int j = 0; j < c_DT_exp_t[0].length; j++) {
						c_DT_exp_t[i][j] = large;	
					}
				}

				//System.out.println();
			}

			//System.out.println(c_x_t.length);
			//System.out.println(c_x_t[0].length);


			KM kkmm = new KM (c_DT_exp_t);

			//System.out.println( "**********");

			int[] match = kkmm.getMatch(-1); // index: cloudlet, value: request //���ڼ�¼���ս���ж���yƥ��Ķ���x
			//System.out.println("*****************");
			//System.out.println(match.length);
			//System.out.println( "**********");

			int count = 0; //count the number of admitted requests in this round

			for (int i = 0; i < Nodes_t.length; i++) { //
				//System.out.println(match[i]);
				//if ((int)c_x_t[match[i]][i] != (int) large) { // i : cloudlet, match[i] : request
				if (admission_DT[match[i]] == false) { // request match[i] is not admitted
					//cost += c_x[match[i]][i];
					Nodes_t[i].put(DTs_t[match[i]]);

					assign_DT[match[i]] = i;

					admission_DT[match[i]] = true; // request match[i] now is admitted
					count ++;	

					//System.out.println("Assign DT " + match[i] +" to cloudlet " + i);
				}
				//}
				//else
			}
			//count ++;

			flag = false;
			for (int i = 0; i < admission_DT.length; i++) {
				if (admission_DT[i] == false) { // if it exists one request not admitted, it will keep looping
					flag = true;
					break;
				}
			}
			//System.out.println("<<<<<<<<<<<<<<");
			//System.out.println(count);

			if (count == 0) {
				break;
			}
		}



		System.out.println("begin to place models");
		////////////////////////// 
		// Place models

		double[][] c_m_exp = new double [models_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < models_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_m_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < models_t.length; i++) {
			int [] m_DTs_index = models_t[i].getDTs();

			for (int j = 0; j < Nodes_t.length; j++) {

				c_m_exp[i][j] += models_t[i].getConsump() * instantiation_ratio;

				for (int k = 0; k < m_DTs_index.length; k++) {
					int DT_index = m_DTs_index[k];
					int loc_k = assign_DT[DT_index];
					double c_trans = DTs_t[DT_index].getWorker_size() * shortestD_map[loc_k][j];
					c_m_exp[i][j] += c_trans;
					double c_m_proc = DTs_t[DT_index].getWorker_size() * Nodes_t[j].getProc_cost();
					c_m_exp[i][j] += c_m_proc;
				}
			}
		}

		int [] assign_m = new int [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			assign_m[i] = -1;
		}

		boolean[] admission_m = new boolean [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			admission_m[i] = false; // initially all DTs are not admitted;
		}

		boolean flag_m = true;
		while (flag_m) {

			int index = max(models_t.length,Nodes_t.length);

			double[][] c_m_exp_t = new double [index][index]; // cost of offloading k to v
			//System.out.println(c_x_t.length);

			//int ccc = 0;
			for (int i = 0; i < c_m_exp_t.length; i++) { // requests
				if (i < models_t.length) {
					for (int j = 0; j < c_m_exp_t[0].length; j++) { // cloudlets
						if (admission_m[i] == false) { // the request i has not been admitted
							if (j < Nodes_t.length) {
								if (Nodes_t[j].enough(models_t[i]) == false) {
									c_m_exp_t[i][j] = large;
									//System.out.println( "!");
								}
								else{
									c_m_exp_t[i][j] = (int) (c_m_exp[i][j]*100);
									//System.out.println(c_m_exp_t[i][j]);
									//c_x_t[i][j] = c_x[i][j] ;
								}
								//c_x_t[i][j] = (int)c_x[i + count * Nodes_t.length][j] ; // int ��double��
								//Random random = new Random();
								//double d = Math.random();
								//System.out.println(d);
								//c_x_t[i][j] = c_x[i + count * Nodes_t.length][j] ;
								//c_x_t[i][j] = d;
								//if (j != c_x_t[0].length-1)
								//	System.out.print( c_x_t[i][j] + ", ");
								//else
								//	System.out.print( c_x_t[i][j] + "}, ");
							}
							else {
								c_m_exp_t[i][j] = large;  //j >= Nodes_t.length, virtual cloudlet nodes
							}

						}
						else {// the request i has been admitted
							c_m_exp_t[i][j] = large;
						}
					}
				}
				else {
					for (int j = 0; j < c_m_exp_t[0].length; j++) {
						c_m_exp_t[i][j] = large;	
					}
				}
				//System.out.println();
			}

			KM kkmm = new KM (c_m_exp_t);

			//System.out.println( "**********");

			int[] match = kkmm.getMatch(-1); // index: cloudlet, value: request //���ڼ�¼���ս���ж���yƥ��Ķ���x
			//System.out.println("*****************");
			//System.out.println(match.length);
			//System.out.println( "**********");

			int count = 0; //count the number of admitted requests in this round

			for (int i = 0; i < Nodes_t.length; i++) { //
				//System.out.println(match[i]);
				//if ((int)c_x_t[match[i]][i] != (int) large) { // i : cloudlet, match[i] : request


				if (admission_m[match[i]] == false) { // request match[i] is not admitted
					//cost += c_x[match[i]][i];
					Nodes_t[i].put(models_t[match[i]]);

					assign_m[match[i]] = i;

					admission_m[match[i]] = true; // request match[i] now is admitted
					count ++;
				}
				//}
				//else
			}

			//count ++;

			flag_m = false;
			for (int i = 0; i < admission_m.length; i++) {
				if (admission_m[i] == false) { // if it exists one request not admitted, it will keep looping
					flag_m = true;
					break;
				}
			}
			//System.out.println("<<<<<<<<<<<<<<");
			//System.out.println(count);

			if (count == 0) {
				break;
			}
		}

		double accumFidMinusNonmig = 0; // the right side of Ineq.(25)

		for (int t = 0; t < Time_num; t++){
			
			double t_accumFidMinusNonmig  = accumFidMinusNonmig;

			//int[] IoT_loc = new int [IoTs_t.length]; 

			// initialize the profit table

			clear(Nodes_t);
			//clear(IoTs_t);

			//////////////////
			//migrations get the potential migrations.

			//migrate DTs

			for (int i = 0; i < DTs_t.length; i++) {
				admission_DT[i] = false; // initially all DTs are not admitted;
			}

			double[][] new_c_DT_exp = new double [DTs_t.length][Nodes_t.length]; // cost of offloading k to v
			for (int i = 0; i < DTs_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j++) {
					new_c_DT_exp[i][j] = 0;
				}
			}

			for (int i = 0; i < DTs_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j++) {

					if (assign_DT[i]!= j) {
						new_c_DT_exp[i][j] += DTs_t[i].getConsump() * instantiation_ratio;
						new_c_DT_exp[i][j] += IoTs_t[i].getCollected() * migration_ratio * shortestD_map[assign_DT[i]][j];
					}

					int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
					int K = loc.length;
					int loc_k = loc[t%K]; // the location of the IoT device at time t

					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[loc_k];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[loc_k][j];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[j].getProc_cost();
					new_c_DT_exp[i][j] += (c_upload + c_trans + c_DT_proc);
				}
			}

			int [] new_assign_DT = new int [DTs_t.length];
			for (int i = 0; i < DTs_t.length; i++) {
				new_assign_DT[i] = -1;
			}

			///////////////////////////////////

			//try to migrate DTs

			for (int i = 0; i < DTs_t.length; i++) {
				admission_DT[i] = false; // initially all DTs are not admitted;
			}

			flag = true;
			while (flag) {

				//System.out.println(count);

				int index = max(DTs_t.length,Nodes_t.length);

				double[][]  new_c_DT_exp_t = new double [index][index]; // cost of offloading k to v
				//System.out.println(c_x_t.length);

				//int ccc = 0;
				for (int i = 0; i < new_c_DT_exp_t.length; i++) { // requests
					if (i < DTs_t.length) {
						for (int j = 0; j < new_c_DT_exp_t[0].length; j++) { // cloudlets
							if (admission_DT[i] == false) { // the request i has not been admitted
								if (j < Nodes_t.length) {
									if (Nodes_t[j].enough(DTs_t[i]) == false) {
										new_c_DT_exp_t[i][j] = large;
										//System.out.println( "!");
									}
									else{
										new_c_DT_exp_t[i][j] = (int)(new_c_DT_exp[i][j]*100);
									}
								}
								else {
									new_c_DT_exp_t[i][j] = large;  //j >= Nodes_t.length, virtual cloudlet nodes
								}

							}
							else {// the request i has been admitted
								new_c_DT_exp_t[i][j] = large;
							}
						}
					}
					else {
						for (int j = 0; j < new_c_DT_exp_t[0].length; j++) {
							new_c_DT_exp_t[i][j] = large;	
						}
					}

				}				

				KM new_dt_kkmm = new KM (new_c_DT_exp_t);

				//System.out.println( "**********");

				int[] new_dt_match = new_dt_kkmm.getMatch(-1); // index: cloudlet, value: request //���ڼ�¼���ս���ж���yƥ��Ķ���x
				//System.out.println("*****************");
				//System.out.println(match.length);
				//System.out.println( "**********");

				int count = 0; //count the number of admitted requests in this round

				for (int i = 0; i < Nodes_t.length; i++) { //
					//System.out.println(match[i]);
					//if ((int)c_x_t[match[i]][i] != (int) large) { // i : cloudlet, match[i] : request
					if (admission_DT[new_dt_match[i]] == false) { // request match[i] is not admitted
						//cost += c_x[match[i]][i];
						Nodes_t[i].put(DTs_t[new_dt_match[i]]);

						//System.out.println("New assign DT " + new_dt_match[i] +" to cloudlet " + i);

						new_assign_DT[new_dt_match[i]] = i;

						admission_DT[new_dt_match[i]] = true; // request match[i] now is admitted
						count ++;	
					}
					//}
					//else
				}
				//count ++;

				flag = false;
				for (int i = 0; i < admission_DT.length; i++) {
					if (admission_DT[i] == false) { // if it exists one request not admitted, it will keep looping
						flag = true;
						break;
					}
				}
				//System.out.println("<<<<<<<<<<<<<<");
				//System.out.println(count);

				if (count == 0) {
					break;
				}
			}


			/////////////////////////////////////////


			//migrate models

			double[][] new_c_m_exp = new double [models_t.length][Nodes_t.length]; // cost of offloading k to v
			for (int i = 0; i < models_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j++) {
					new_c_m_exp[i][j] = 0;
				}
			}

			for (int i = 0; i < models_t.length; i++) {
				int [] m_DTs_index = models_t[i].getDTs();

				for (int j = 0; j < Nodes_t.length; j++) {

					if (assign_m[i]!= j) {
						new_c_m_exp[i][j] += models_t[i].getConsump() * instantiation_ratio;
						new_c_m_exp[i][j] += models_t[i].getModelSize() * migration_ratio * shortestD_map[assign_m[i]][j];
					}

					for (int k = 0; k < m_DTs_index.length; k++) {
						int DT_index = m_DTs_index[k];
						int loc_k = assign_DT[DT_index];
						double c_trans = DTs_t[DT_index].getWorker_size() * shortestD_map[loc_k][j];
						new_c_m_exp[i][j] += c_trans;
						double c_m_proc = DTs_t[DT_index].getWorker_size() * Nodes_t[j].getProc_cost();
						new_c_m_exp[i][j] += c_m_proc;
					}
				}
			}

			int [] new_assign_m = new int [models_t.length];
			for (int i = 0; i < models_t.length; i++) {
				new_assign_m[i] = -1;
			}

			//////////////////////

			//try to migrate models

			for (int i = 0; i < models_t.length; i++) {
				admission_m[i] = false; // initially all DTs are not admitted;
			}

			flag_m = true;
			while (flag_m) {

				int index_m = max(models_t.length,Nodes_t.length);

				double[][] new_c_m_exp_t = new double [index_m][index_m]; // cost of offloading k to v
				//System.out.println(c_x_t.length);

				//int ccc = 0;
				for (int i = 0; i < new_c_m_exp_t.length; i++) { // requests
					if (i < models_t.length) {
						for (int j = 0; j < new_c_m_exp_t[0].length; j++) { // cloudlets
							if (admission_m[i] == false) { // the request i has not been admitted
								if (j < Nodes_t.length) {
									if (Nodes_t[j].enough(models_t[i]) == false) {
										new_c_m_exp_t[i][j] = large;
										//System.out.println( "!");
									}
									else{
										new_c_m_exp_t[i][j] = (int) (new_c_m_exp[i][j]*100);
										//System.out.println(c_m_exp_t[i][j]);
										//c_x_t[i][j] = c_x[i][j] ;
									}
								}
								else {
									new_c_m_exp_t[i][j] = large;  //j >= Nodes_t.length, virtual cloudlet nodes
								}

							}
							else {// the request i has been admitted
								new_c_m_exp_t[i][j] = large;
							}
						}
					}
					else {
						for (int j = 0; j < new_c_m_exp_t[0].length; j++) {
							new_c_m_exp_t[i][j] = large;	
						}
					}
					//System.out.println();
				}

				KM new_kkmm_m = new KM (new_c_m_exp_t);

				//System.out.println( "**********");

				int[] new_match_m = new_kkmm_m.getMatch(-1); // index: cloudlet, value: request //���ڼ�¼���ս���ж���yƥ��Ķ���x
				//System.out.println("*****************");
				//System.out.println(match.length);
				//System.out.println( "**********");

				int count = 0; //count the number of admitted requests in this round

				for (int i = 0; i < Nodes_t.length; i++) { //
					//System.out.println(match[i]);
					//if ((int)c_x_t[match[i]][i] != (int) large) { // i : cloudlet, match[i] : request


					if (admission_m[new_match_m[i]] == false) { // request match[i] is not admitted
						//cost += c_x[match[i]][i];
						Nodes_t[i].put(models_t[new_match_m[i]]);

						new_assign_m[new_match_m[i]] = i;

						admission_m[new_match_m[i]] = true; // request match[i] now is admitted
						count ++;
					}
					//}
					//else
				}

				//count ++;

				flag_m = false;
				for (int i = 0; i < admission_m.length; i++) {
					if (admission_m[i] == false) { // if it exists one request not admitted, it will keep looping
						flag_m = true;
						break;
					}
				}
				//System.out.println("<<<<<<<<<<<<<<");
				//System.out.println(count);

				if (count == 0) {
					break;
				}
			}


			///////////////////////////**********************
			//finish potential migrations
			// schedule updates

			//calculate the migration cost and nonmigration cost


			double dynamic_cost_t = 0;

			for (int i = 0; i < DTs_t.length; i++) {
				if(assign_DT[i] != new_assign_DT[i]) {
					dynamic_cost_t += omega * DTs_t[i].getConsump() * instantiation_ratio;
					//System.out.println("assign_DT[i]: " + assign_DT[i]);
					//System.out.println("new_assign_DT[i]: " + new_assign_DT[i]);

					dynamic_cost_t += omega * IoTs_t[i].getCollected() * migration_ratio * shortestD_map[assign_DT[i]][new_assign_DT[i]];
					//assign_DT[i] = new_assign_DT[i];
				}
			}

			for (int i = 0; i < assign_m.length; i++) {
				if(assign_m[i] != new_assign_m[i]) {
					dynamic_cost_t += omega * models_t[i].getConsump() * instantiation_ratio;;
					dynamic_cost_t += omega * models_t[i].getModelSize() * migration_ratio * shortestD_map[assign_m[i]][new_assign_m[i]];
					//assign_m[i] = new_assign_m[i];
				}
			}

			double[][] obj = new double[IoTs_t.length][Nodes_t.length];

			double[][] fid_gain = new double[IoTs_t.length][Nodes_t.length];
			for (int i = 0; i < IoTs_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
					obj[i][j] = 0;
					fid_gain[i][j] = 0;
					for (int m = 0; m < models_t.length; m++) {
						int [] m_DTs_index = models_t[m].getDTs();
						int K = m_DTs_index.length;
						for (int k = 0; k < K; k++) {
							if (m_DTs_index[k] == i) {
								obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]) / K;
								fid_gain[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]) / K;
								//obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]);
							}
						}
					}
					//System.out.println(obj[i][j]);
				}
			}

			//for (int i = 0; i < IoTs_t.length; i++) {
			//	for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
			//		System.out.println(obj[i][j]);
			//	}
			//}

			//double[][] nonmigration_cost = new double[IoTs_t.length][Nodes_t.length];

			for (int i = 0; i < IoTs_t.length; i++) {
				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				int loc_k = loc[t%K]; // the location of the IoT device at time t
				for (int j = 0; j < Nodes_t.length; j ++) {
					//nonmigration_cost[i][j] = 0;

					if (loc_k == j || connect_map_t[loc_k][j] == 1) {
						double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[j];
						double c_trans = DTs_t[i].getRaw_size() * shortestD_map[j][new_assign_DT[i]];
						double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[new_assign_DT[i]].getProc_cost();
						double c_m_trans = 0;
						double c_m_proc = 0;
						for (int m = 0; m < models_t.length; m++) {
							int [] m_DTs_index = models_t[m].getDTs();
							int KK = m_DTs_index.length;
							for (int k = 0; k < KK; k++) {
								if (m_DTs_index[k] == i) {
									c_m_trans += DTs_t[i].getWorker_size() * shortestD_map[new_assign_DT[i]][new_assign_m[m]];
									c_m_proc += DTs_t[i].getWorker_size() * Nodes_t[new_assign_m[m]].getProc_cost();
								}
							}
						}
						//nonmigration_cost[i][j] -= omega * (c_upload + c_trans + c_DT_proc + c_m_trans + c_m_proc);
						obj[i][j] -= omega * (c_upload + c_trans + c_DT_proc + c_m_trans + c_m_proc);

					}
					else {
						//nonmigration_cost[i][j] = 0;
						obj[i][j] = 0;
					}
				}
			}

			//double [][] h_table = new double [N] [Nodes_t.length]; 
			double [][] ratio_table = new double [IoTs_t.length] [Nodes_t.length]; 
			// the utility gain table, i.e., the profit table

			for (int n = 0; n < IoTs_t.length; n++) { // for each worker DT //build the tables
				for (int v = 0; v < Nodes_t.length; v++) { // for each possible placement of worker DT
					//ratio_table[n][v] = obj[n][v] / (IoTs_t[n].getBand()[v] / Nodes_t[v].getBand_cap());
					ratio_table[n][v] = obj[n][v];
				}

			}

			int [] assign_IoT = new int [IoTs_t.length];
			for (int i = 0; i< assign_IoT.length; i++) {
				assign_IoT[i] = -1;
			}

			//System.out.println("length of IoT devices: " + IoTs_t.length);

			int count = 0;
			for (int i = 0; i < assign_IoT.length; i++) {

				double max_ratio = 0; // the placement of DT with the maximum ratio of utility/consumed resource
				int max_o_index = -1; // the index of the worker DT
				int max_v_index = -1; // the assigned cloudlet

				for (int j = 0; j < assign_IoT.length; j++) {
					if (assign_IoT[j] == -1) {//DT j has not been assigned to any cloudlet
						for (int v = 0; v < Nodes_t.length; v++) {
							if (Nodes_t[v].enough_band(IoTs_t[j]) && ratio_table[j][v] > max_ratio) {
								max_ratio = ratio_table[j][v];
								max_o_index = j;
								max_v_index = v;
							}
						}
					}
				}

				if (max_o_index != -1) { 

					count ++;
					assign_IoT[max_o_index] = max_v_index;
					Nodes_t[max_v_index].put(IoTs_t[max_o_index]);
					//tot_u += obj[max_o_index][max_v_index];
					//IoTs_t[max_o_index].add(DTs_t[max_o_index]);

					t_accumFidMinusNonmig += obj[max_o_index][max_v_index];
				}
			}


			//*****************************
			// condition
			//*****************************
			if (dynamic_cost_t <= (1/beta) * t_accumFidMinusNonmig) {
			//if (true) {
			//if (false) {
				accumFidMinusNonmig = 0;


				for (int i = 0; i < assign_DT.length; i++) {
					assign_DT[i] = new_assign_DT[i];
				}

				for (int i = 0; i < assign_m.length; i++) {
					assign_m[i] = new_assign_m[i];
				}
				
				//System.out.println(dynamic_cost_t);

				tot_u -= dynamic_cost_t;
				
				//record_cost += dynamic_cost_t;

				for (int i = 0; i < assign_IoT.length; i++) {
					if (assign_IoT[i] != -1) {
						tot_u += obj[i][assign_IoT[i]];
						//record_fid += obj[i][assign_IoT[i]];
								
						IoTs_t[i].add(DTs_t[i]);
					}
				}
			}
			else{
				//******************************

				clear_band(Nodes_t);

				for (int i = 0; i < IoTs_t.length; i++) {
					for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
						obj[i][j] = 0;
						fid_gain[i][j] = 0;
						for (int m = 0; m < models_t.length; m++) {
							int [] m_DTs_index = models_t[m].getDTs();
							int K = m_DTs_index.length;
							for (int k = 0; k < K; k++) {
								if (m_DTs_index[k] == i) {
									obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]) / K;
									fid_gain[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]) / K;
									//obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]);
								}
							}
						}
						//System.out.println(obj[i][j]);
					}
				}
				
				

				//for (int i = 0; i < IoTs_t.length; i++) {
				//	for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
				//		System.out.println(obj[i][j]);
				//	}
				//}


				for (int i = 0; i < IoTs_t.length; i++) {
					int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
					int K = loc.length;
					int loc_k = loc[t%K]; // the location of the IoT device at time t
					for (int j = 0; j < Nodes_t.length; j ++) {
						if (loc_k == j || connect_map_t[loc_k][j] == 1) {
							double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[j];
							double c_trans = DTs_t[i].getRaw_size() * shortestD_map[j][assign_DT[i]];
							double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[assign_DT[i]].getProc_cost();
							double c_m_trans = 0;
							double c_m_proc = 0;
							for (int m = 0; m < models_t.length; m++) {
								int [] m_DTs_index = models_t[m].getDTs();
								int KK = m_DTs_index.length;
								for (int k = 0; k < KK; k++) {
									if (m_DTs_index[k] == i) {
										c_m_trans += DTs_t[i].getWorker_size() * shortestD_map[assign_DT[i]][assign_m[m]];
										c_m_proc += DTs_t[i].getWorker_size() * Nodes_t[assign_m[m]].getProc_cost();
									}
								}
							}
							obj[i][j] -= omega * (c_upload + c_trans + c_DT_proc + c_m_trans + c_m_proc);

						}
						else {
							obj[i][j] = 0;
						}
					}
				}

				//double [][] h_table = new double [N] [Nodes_t.length]; 
				//ratio_table = new double [IoTs_t.length] [Nodes_t.length]; 
				// the utility gain table, i.e., the profit table

				for (int n = 0; n < IoTs_t.length; n++) { // for each worker DT //build the tables
					for (int v = 0; v < Nodes_t.length; v++) { // for each possible placement of worker DT
						//ratio_table[n][v] = obj[n][v] / (IoTs_t[n].getBand()[v] / Nodes_t[v].getBand_cap());
						ratio_table[n][v] = obj[n][v];
					}

				}

				for (int i = 0; i< assign_IoT.length; i++) {
					assign_IoT[i] = -1;
				}


				//System.out.println("length of IoT devices: " + IoTs_t.length);

				count = 0;
				for (int i = 0; i < assign_IoT.length; i++) {

					double max_ratio = 0; // the placement of DT with the maximum ratio of utility/consumed resource
					int max_o_index = -1; // the index of the worker DT
					int max_v_index = -1; // the assigned cloudlet

					for (int j = 0; j < assign_IoT.length; j++) {
						if (assign_IoT[j] == -1) {//DT j has not been assigned to any cloudlet
							for (int v = 0; v < Nodes_t.length; v++) {
								if (Nodes_t[v].enough_band(IoTs_t[j]) && ratio_table[j][v] > max_ratio) {
									max_ratio = ratio_table[j][v];
									max_o_index = j;
									max_v_index = v;
								}
							}
						}
					}

					if (max_o_index != -1) { 

						count ++;
						assign_IoT[max_o_index] = max_v_index;
						Nodes_t[max_v_index].put(IoTs_t[max_o_index]);
						tot_u += obj[max_o_index][max_v_index];
						//record_fid += obj[max_o_index][max_v_index];
						IoTs_t[max_o_index].add(DTs_t[max_o_index]);

						accumFidMinusNonmig += obj[max_o_index][max_v_index];
					}
				}

			}




			//System.out.println("number of admitted IoT devices: " + count);

			//System.out.println("time: " + t + ", u: "+ tot_u);
			
			if ((t + 1) %5 == 0) {
				
				double tttt =  System.currentTimeMillis() - startTime;
				
				double logtttt = java.lang.Math.log10(tttt);
						
				System.out.print("time slot: " + t + ", t = " + tttt + ", log t = " + logtttt + ", u = " + tot_u);
			}
		}

		//System.out.println("record_fid: " + record_fid);
		//System.out.println("record_cost: " + record_cost);
		
		clear_band(Nodes_t);

		clear(Nodes_t);
		clear(IoTs_t);

		long endTime = System.currentTimeMillis();

		res result= new res (tot_u, endTime -startTime);

		return result;


		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		//for (int i = 0; i < used.length; i++) {
		//	System.out.println("cloudlet " + i +": residual: " + used[i] + ", capacity: " + Nodes_t[i].getCapacity() );
		//}
	}


	public static res gdy_u(double[][] connect_map_t, double[][] cost_map_t, Node[] Nodes_t, Objectt[] IoTs_t, DT [] DTs_t, model [] models_t) {
		//heu.1

		long startTime = System.currentTimeMillis();
		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		double tot_u = 0;

		double [][] shortestD_map = new double[cost_map_t.length][cost_map_t[0].length];

		for (int i = 0; i< cost_map_t.length; i++) { //print shortest delay
			shortestD_map[i] = dijkstra_alg(i, cost_map_t).getValue();
		}

		double[][] c_DT_exp = new double [DTs_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_DT_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {

				c_DT_exp[i][j] += DTs_t[i].getConsump() * instantiation_ratio;

				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				for (int k = 0; k < K; k++) {
					int loc_k = loc[k];
					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[loc_k];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[loc_k][j];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[j].getProc_cost();
					c_DT_exp[i][j] += (c_upload + c_trans + c_DT_proc) / K;
				}
			}
		}


		System.out.println("gdy_u: begin to place DTs");

		int [] assign_DT = new int [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			assign_DT[i] = -1;
		}

		boolean[] admission_DT = new boolean [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			admission_DT[i] = false; // initially all DTs are not admitted;
		}


		int count = 0;
		for (int i = 0; i < assign_DT.length; i++) {

			double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
			//int max_o_index = -1; // the index of the worker DT
			int min_v_index = -1; // the assigned cloudlet

			for (int v = 0; v < Nodes_t.length; v++) {
				if (Nodes_t[v].enough(DTs_t[i]) && c_DT_exp[i][v] < min_cost) {
					min_cost = c_DT_exp[i][v];
					//max_o_index = j;
					min_v_index = v;
				}
			}
			if (min_v_index != -1) { 

				tot_u += c_DT_exp[i][min_v_index];

				count ++;
				assign_DT[i] = min_v_index;
				Nodes_t[min_v_index].put(DTs_t[i]);
			}
		}


		System.out.println("begin to place models");
		////////////////////////// 
		// Place models

		double[][] c_m_exp = new double [models_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < models_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_m_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < models_t.length; i++) {
			int [] m_DTs_index = models_t[i].getDTs();

			for (int j = 0; j < Nodes_t.length; j++) {

				c_m_exp[i][j] += models_t[i].getConsump() * instantiation_ratio;

				for (int k = 0; k < m_DTs_index.length; k++) {
					int DT_index = m_DTs_index[k];
					int loc_k = assign_DT[DT_index];
					double c_trans = DTs_t[DT_index].getWorker_size() * shortestD_map[loc_k][j];
					c_m_exp[i][j] += c_trans;
					double c_m_proc = DTs_t[DT_index].getWorker_size() * Nodes_t[j].getProc_cost();
					c_m_exp[i][j] += c_m_proc;
				}
			}
		}

		int [] assign_m = new int [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			assign_m[i] = -1;
		}

		boolean[] admission_m = new boolean [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			admission_m[i] = false; // initially all DTs are not admitted;
		}

		count = 0;
		for (int i = 0; i < assign_m.length; i++) {

			double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
			//int max_o_index = -1; // the index of the worker DT
			int min_v_index = -1; // the assigned cloudlet

			for (int v = 0; v < Nodes_t.length; v++) {
				if (Nodes_t[v].enough(models_t[i]) && c_m_exp[i][v] < min_cost) {
					min_cost = c_m_exp[i][v];
					//max_o_index = j;
					min_v_index = v;
				}
			}
			if (min_v_index != -1) { 

				tot_u += c_m_exp[i][min_v_index]; /////////

				count ++;
				assign_m[i] = min_v_index;
				Nodes_t[min_v_index].put(models_t[i]);
			}
		}


		clear(Nodes_t);
		clear(IoTs_t);

		long endTime = System.currentTimeMillis();

		res result= new res (tot_u, endTime -startTime);

		return result;


		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		//for (int i = 0; i < used.length; i++) {
		//	System.out.println("cloudlet " + i +": residual: " + used[i] + ", capacity: " + Nodes_t[i].getCapacity() );
		//}
	}

	public static res gdy_u_2(double[][] connect_map_t, double[][] cost_map_t, Node[] Nodes_t, Objectt[] IoTs_t, DT [] DTs_t, model [] models_t) {
		//heu.1

		long startTime = System.currentTimeMillis();
		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		double tot_u = 0;

		double [][] shortestD_map = new double[cost_map_t.length][cost_map_t[0].length];

		for (int i = 0; i< cost_map_t.length; i++) { //print shortest delay
			shortestD_map[i] = dijkstra_alg(i, cost_map_t).getValue();
		}

		double[][] c_DT_exp = new double [DTs_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_DT_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {

				c_DT_exp[i][j] += DTs_t[i].getConsump() * instantiation_ratio;

				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				for (int k = 0; k < K; k++) {
					int loc_k = loc[k];
					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[loc_k];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[loc_k][j];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[j].getProc_cost();
					c_DT_exp[i][j] += (c_upload + c_trans + c_DT_proc) / K;
				}
			}
		}


		System.out.println("gdy_u: begin to place DTs");

		int [] assign_DT = new int [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			assign_DT[i] = -1;
		}

		boolean[] admission_DT = new boolean [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			admission_DT[i] = false; // initially all DTs are not admitted;
		}


		int count = 0;
		for (int i = 0; i < assign_DT.length; i++) {

			double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
			//int max_o_index = -1; // the index of the worker DT
			int min_v_index = -1; // the assigned cloudlet

			for (int v = 0; v < Nodes_t.length; v++) {
				if (Nodes_t[v].enough(DTs_t[i]) && c_DT_exp[i][v] < min_cost) {
					min_cost = c_DT_exp[i][v];
					//max_o_index = j;
					min_v_index = v;
				}
			}
			if (min_v_index != -1) { 
				count ++;
				assign_DT[i] = min_v_index;
				Nodes_t[min_v_index].put(DTs_t[i]);
			}
		}


		System.out.println("begin to place models");
		////////////////////////// 
		// Place models

		double[][] c_m_exp = new double [models_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < models_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_m_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < models_t.length; i++) {
			int [] m_DTs_index = models_t[i].getDTs();

			for (int j = 0; j < Nodes_t.length; j++) {

				c_m_exp[i][j] += models_t[i].getConsump() * instantiation_ratio;

				for (int k = 0; k < m_DTs_index.length; k++) {
					int DT_index = m_DTs_index[k];
					int loc_k = assign_DT[DT_index];
					double c_trans = DTs_t[DT_index].getWorker_size() * shortestD_map[loc_k][j];
					c_m_exp[i][j] += c_trans;
					double c_m_proc = DTs_t[DT_index].getWorker_size() * Nodes_t[j].getProc_cost();
					c_m_exp[i][j] += c_m_proc;
				}
			}
		}

		int [] assign_m = new int [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			assign_m[i] = -1;
		}

		boolean[] admission_m = new boolean [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			admission_m[i] = false; // initially all DTs are not admitted;
		}

		count = 0;
		for (int i = 0; i < assign_m.length; i++) {

			double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
			//int max_o_index = -1; // the index of the worker DT
			int min_v_index = -1; // the assigned cloudlet

			for (int v = 0; v < Nodes_t.length; v++) {
				if (Nodes_t[v].enough(models_t[i]) && c_m_exp[i][v] < min_cost) {
					min_cost = c_m_exp[i][v];
					//max_o_index = j;
					min_v_index = v;
				}
			}
			if (min_v_index != -1) { 
				count ++;
				assign_m[i] = min_v_index;
				Nodes_t[min_v_index].put(models_t[i]);
			}
		}



		for (int t = 0; t < Time_num; t++){

			//int[] IoT_loc = new int [IoTs_t.length]; 

			// initialize the profit table
			double[][] obj = new double[IoTs_t.length][Nodes_t.length];
			for (int i = 0; i < IoTs_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
					obj[i][j] = 0;
					for (int m = 0; m < models_t.length; m++) {
						int [] m_DTs_index = models_t[m].getDTs();
						int K = m_DTs_index.length;
						for (int k = 0; k < K; k++) {
							if (m_DTs_index[k] == i) {
								obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]) / K;
								//obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]);
							}
						}
					}
					//System.out.println(obj[i][j]);
				}
			}

			//for (int i = 0; i < IoTs_t.length; i++) {
			//	for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
			//		System.out.println(obj[i][j]);
			//	}
			//}


			for (int i = 0; i < IoTs_t.length; i++) {
				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				int loc_k = loc[t%K]; // the location of the IoT device at time t
				for (int j = 0; j < Nodes_t.length; j ++) {
					if (loc_k == j || connect_map_t[loc_k][j] == 1) {
						double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[j];
						double c_trans = DTs_t[i].getRaw_size() * shortestD_map[j][assign_DT[i]];
						double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[assign_DT[i]].getProc_cost();
						double c_m_trans = 0;
						double c_m_proc = 0;
						for (int m = 0; m < models_t.length; m++) {
							int [] m_DTs_index = models_t[m].getDTs();
							int KK = m_DTs_index.length;
							for (int k = 0; k < KK; k++) {
								if (m_DTs_index[k] == i) {
									c_m_trans += DTs_t[i].getWorker_size() * shortestD_map[assign_DT[i]][assign_m[m]];
									c_m_proc += DTs_t[i].getWorker_size() * Nodes_t[assign_m[m]].getProc_cost();
								}
							}
						}
						obj[i][j] -= omega * (c_upload + c_trans + c_DT_proc + c_m_trans + c_m_proc);

					}
					else {
						obj[i][j] = 0;
					}
				}
			}

			//double [][] h_table = new double [N] [Nodes_t.length]; 
			double [][] ratio_table = new double [IoTs_t.length] [Nodes_t.length]; 
			// the utility gain table, i.e., the profit table

			for (int n = 0; n < IoTs_t.length; n++) { // for each worker DT //build the tables
				for (int v = 0; v < Nodes_t.length; v++) { // for each possible placement of worker DT
					//ratio_table[n][v] = obj[n][v] / (IoTs_t[n].getBand()[v] / Nodes_t[v].getBand_cap());
					ratio_table[n][v] = obj[n][v];
				}

			}

			int [] assign_IoT = new int [IoTs_t.length];
			for (int i = 0; i< assign_IoT.length; i++) {
				assign_IoT[i] = -1;
			}


			//System.out.println("length of IoT devices: " + IoTs_t.length);

			count = 0;
			for (int i = 0; i < assign_IoT.length; i++) {

				double max_ratio = 0; // the placement of DT with the maximum ratio of utility/consumed resource
				//int max_o_index = -1; // the index of the worker DT
				int max_v_index = -1; // the assigned cloudlet

				for (int v = 0; v < Nodes_t.length; v++) {
					if (Nodes_t[v].enough_band(IoTs_t[i]) && ratio_table[i][v] > max_ratio) {
						max_ratio = ratio_table[i][v];
						max_v_index = v;
					}
				}

				if (max_v_index != -1) { 
					count ++;
					assign_IoT[i] = max_v_index;
					Nodes_t[max_v_index].put(IoTs_t[i]);
					tot_u += obj[i][max_v_index];
					IoTs_t[i].add(DTs_t[i]);
				}
			}

			//System.out.println("number of admitted IoT devices: " + count);

			clear_band(Nodes_t);

			//System.out.println("time: " + t + ", u: "+ tot_u);
		}

		clear(Nodes_t);
		clear(IoTs_t);

		long endTime = System.currentTimeMillis();

		res result= new res (tot_u, endTime -startTime);

		return result;


		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		//for (int i = 0; i < used.length; i++) {
		//	System.out.println("cloudlet " + i +": residual: " + used[i] + ", capacity: " + Nodes_t[i].getCapacity() );
		//}
	}

	public static res gdy_u_3(double[][] connect_map_t, double[][] cost_map_t, Node[] Nodes_t, Objectt[] IoTs_t, DT [] DTs_t, model [] models_t) {
		//heu.1

		long startTime = System.currentTimeMillis();
		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		double tot_u = 0;

		double [][] shortestD_map = new double[cost_map_t.length][cost_map_t[0].length];

		for (int i = 0; i< cost_map_t.length; i++) { //print shortest delay
			shortestD_map[i] = dijkstra_alg(i, cost_map_t).getValue();
		}

		double[][] c_DT_exp = new double [DTs_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_DT_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {

				c_DT_exp[i][j] += DTs_t[i].getConsump() * instantiation_ratio;

				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				for (int k = 0; k < K; k++) {
					int loc_k = loc[k];
					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[loc_k];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[loc_k][j];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[j].getProc_cost();
					c_DT_exp[i][j] += (c_upload + c_trans + c_DT_proc) / K;
				}
			}
		}


		System.out.println("gdy_u: begin to place DTs");

		int [] assign_DT = new int [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			assign_DT[i] = -1;
		}

		int count = 0;
		for (int i = 0; i < assign_DT.length; i++) {

			double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
			//int max_o_index = -1; // the index of the worker DT
			int min_v_index = -1; // the assigned cloudlet

			for (int v = 0; v < Nodes_t.length; v++) {
				if (Nodes_t[v].enough(DTs_t[i]) && c_DT_exp[i][v] < min_cost) {
					min_cost = c_DT_exp[i][v];
					//max_o_index = j;
					min_v_index = v;
				}
			}
			if (min_v_index != -1) { 
				count ++;
				assign_DT[i] = min_v_index;
				Nodes_t[min_v_index].put(DTs_t[i]);
			}
		}


		System.out.println("begin to place models");
		////////////////////////// 
		// Place models

		double[][] c_m_exp = new double [models_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < models_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_m_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < models_t.length; i++) {
			int [] m_DTs_index = models_t[i].getDTs();

			for (int j = 0; j < Nodes_t.length; j++) {

				c_m_exp[i][j] += models_t[i].getConsump() * instantiation_ratio;

				for (int k = 0; k < m_DTs_index.length; k++) {
					int DT_index = m_DTs_index[k];
					int loc_k = assign_DT[DT_index];
					double c_trans = DTs_t[DT_index].getWorker_size() * shortestD_map[loc_k][j];
					c_m_exp[i][j] += c_trans;
					double c_m_proc = DTs_t[DT_index].getWorker_size() * Nodes_t[j].getProc_cost();
					c_m_exp[i][j] += c_m_proc;
				}
			}
		}

		int [] assign_m = new int [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			assign_m[i] = -1;
		}


		count = 0;
		for (int i = 0; i < assign_m.length; i++) {

			double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
			//int max_o_index = -1; // the index of the worker DT
			int min_v_index = -1; // the assigned cloudlet

			for (int v = 0; v < Nodes_t.length; v++) {
				if (Nodes_t[v].enough(models_t[i]) && c_m_exp[i][v] < min_cost) {
					min_cost = c_m_exp[i][v];
					//max_o_index = j;
					min_v_index = v;
				}
			}
			if (min_v_index != -1) { 
				count ++;
				assign_m[i] = min_v_index;
				Nodes_t[min_v_index].put(models_t[i]);
			}
		}

		for (int t = 0; t < Time_num; t++){

			clear(Nodes_t);

			// migration
			/////////////////////////////////

			// migrate DTs

			double[][] new_c_DT_exp = new double [DTs_t.length][Nodes_t.length]; // cost of offloading k to v
			for (int i = 0; i < DTs_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j++) {
					new_c_DT_exp[i][j] = 0;
				}
			}

			for (int i = 0; i < DTs_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j++) {

					if (assign_DT[i]!= j) {
						new_c_DT_exp[i][j] += DTs_t[i].getConsump() * instantiation_ratio;
						new_c_DT_exp[i][j] += IoTs_t[i].getCollected() * migration_ratio * shortestD_map[assign_DT[i]][j];
						
						//System.out.println("migration cost " + new_c_DT_exp[i][j]);
					}

					int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
					int K = loc.length;
					int loc_k = loc[t%K]; // the location of the IoT device at time t

					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[loc_k];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[loc_k][j];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[j].getProc_cost();
					
					//double aaaaa = c_upload + c_trans + c_DT_proc;
					
					//System.out.println("nonmigration cost " + aaaaa);
					
					new_c_DT_exp[i][j] += (c_upload + c_trans + c_DT_proc);
				}
			}

			int[] new_assign_DT = new int [DTs_t.length];
			for (int i = 0; i < DTs_t.length; i++) {
				new_assign_DT[i] = -1;
			}

			for (int i = 0; i < new_assign_DT.length; i++) {

				double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
				//int max_o_index = -1; // the index of the worker DT
				int min_v_index = -1; // the assigned cloudlet

				for (int v = 0; v < Nodes_t.length; v++) {
					if (Nodes_t[v].enough(DTs_t[i]) && new_c_DT_exp[i][v] < min_cost) {
						min_cost = new_c_DT_exp[i][v];
						//max_o_index = j;
						min_v_index = v;
					}
				}
				if (min_v_index != -1) { 
					count ++;
					new_assign_DT[i] = min_v_index;
					Nodes_t[min_v_index].put(DTs_t[i]);
				}
			}

			//&&&&&&&&&&&&&&&&&&&&&&&&&
			double migration_cost = 0;
			for (int i = 0; i < DTs_t.length; i++) {
				if(assign_DT[i] != new_assign_DT[i]) {
					tot_u -= omega * DTs_t[i].getConsump() * instantiation_ratio;
					tot_u -= omega * IoTs_t[i].getCollected() * migration_ratio * shortestD_map[assign_DT[i]][new_assign_DT[i]];
					assign_DT[i] = new_assign_DT[i];
					
					migration_cost += omega * DTs_t[i].getConsump() * instantiation_ratio + omega * IoTs_t[i].getCollected() * migration_ratio * shortestD_map[assign_DT[i]][new_assign_DT[i]];
				}
			}


			// migrate models

			double[][] new_c_m_exp = new double [models_t.length][Nodes_t.length]; // cost of offloading k to v
			for (int i = 0; i < models_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j++) {
					new_c_m_exp[i][j] = 0;
				}
			}

			for (int i = 0; i < models_t.length; i++) {
				int [] m_DTs_index = models_t[i].getDTs();

				for (int j = 0; j < Nodes_t.length; j++) {

					if (assign_m[i]!= j) {
						new_c_m_exp[i][j] += models_t[i].getConsump() * instantiation_ratio;
						new_c_m_exp[i][j] += models_t[i].getModelSize() * migration_ratio * shortestD_map[assign_m[i]][j];
					}

					for (int k = 0; k < m_DTs_index.length; k++) {
						int DT_index = m_DTs_index[k];
						int loc_k = assign_DT[DT_index];
						double c_trans = DTs_t[DT_index].getWorker_size() * shortestD_map[loc_k][j];
						new_c_m_exp[i][j] += c_trans;
						double c_m_proc = DTs_t[DT_index].getWorker_size() * Nodes_t[j].getProc_cost();
						new_c_m_exp[i][j] += c_m_proc;
					}
				}
			}

			int [] new_assign_m = new int [models_t.length];
			for (int i = 0; i < models_t.length; i++) {
				new_assign_m[i] = -1;
			}

			count = 0;
			for (int i = 0; i < assign_m.length; i++) {

				double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
				//int max_o_index = -1; // the index of the worker DT
				int min_v_index = -1; // the assigned cloudlet

				for (int v = 0; v < Nodes_t.length; v++) {
					if (Nodes_t[v].enough(models_t[i]) && new_c_m_exp[i][v] < min_cost) {
						min_cost = new_c_m_exp[i][v];
						//max_o_index = j;
						min_v_index = v;
					}
				}
				if (min_v_index != -1) { 
					count ++;
					new_assign_m[i] = min_v_index;
					Nodes_t[min_v_index].put(models_t[i]);
				}
			}


			//&&&&&&&&&&&&&&&&&&&&&&&&&
			for (int i = 0; i < assign_m.length; i++) {
				if(assign_m[i] != new_assign_m[i]) {
					tot_u -= omega * models_t[i].getConsump() * instantiation_ratio;
					tot_u -= omega * models_t[i].getModelSize() * migration_ratio * shortestD_map[assign_m[i]][new_assign_m[i]];
					assign_m[i] = new_assign_m[i];
					
					migration_cost += omega * models_t[i].getConsump() * instantiation_ratio + omega * models_t[i].getModelSize() * migration_ratio * shortestD_map[assign_m[i]][new_assign_m[i]];
				}
			}
			
			System.out.println(migration_cost);


			////////////////////////////////////////////

			//int[] IoT_loc = new int [IoTs_t.length]; 

			// initialize the profit table
			double[][] obj = new double[IoTs_t.length][Nodes_t.length];
			for (int i = 0; i < IoTs_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
					obj[i][j] = 0;
					for (int m = 0; m < models_t.length; m++) {
						int [] m_DTs_index = models_t[m].getDTs();
						int K = m_DTs_index.length;
						for (int k = 0; k < K; k++) {
							if (m_DTs_index[k] == i) {
								obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]) / K;
								//obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]);
							}
						}
					}
					//System.out.println(obj[i][j]);
				}
			}

			//for (int i = 0; i < IoTs_t.length; i++) {
			//	for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
			//		System.out.println(obj[i][j]);
			//	}
			//}


			for (int i = 0; i < IoTs_t.length; i++) {
				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				int loc_k = loc[t%K]; // the location of the IoT device at time t
				for (int j = 0; j < Nodes_t.length; j ++) {
					if (loc_k == j || connect_map_t[loc_k][j] == 1) {
						
						//System.out.print("In time slot " +t + ", assign ioT device " + i + " to cloudlet " + j + ", gets fid: " + obj[i][j]);
						
						
						double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[j];
						double c_trans = DTs_t[i].getRaw_size() * shortestD_map[j][assign_DT[i]];
						double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[assign_DT[i]].getProc_cost();
						double c_m_trans = 0;
						double c_m_proc = 0;
						for (int m = 0; m < models_t.length; m++) {
							int [] m_DTs_index = models_t[m].getDTs();
							int KK = m_DTs_index.length;
							for (int k = 0; k < KK; k++) {
								if (m_DTs_index[k] == i) {
									c_m_trans += DTs_t[i].getWorker_size() * shortestD_map[assign_DT[i]][assign_m[m]];
									c_m_proc += DTs_t[i].getWorker_size() * Nodes_t[assign_m[m]].getProc_cost();
								}
							}
						}
						obj[i][j] -= omega * (c_upload + c_trans + c_DT_proc + c_m_trans + c_m_proc);
						
						//System.out.println(", and the cost is" +  omega * (c_upload + c_trans + c_DT_proc + c_m_trans + c_m_proc));

					}
					else {
						obj[i][j] = 0;
					}
				}
			}

			//double [][] h_table = new double [N] [Nodes_t.length]; 
			double [][] ratio_table = new double [IoTs_t.length] [Nodes_t.length]; 
			// the utility gain table, i.e., the profit table

			for (int n = 0; n < IoTs_t.length; n++) { // for each worker DT //build the tables
				for (int v = 0; v < Nodes_t.length; v++) { // for each possible placement of worker DT
					//ratio_table[n][v] = obj[n][v] / (IoTs_t[n].getBand()[v] / Nodes_t[v].getBand_cap());
					ratio_table[n][v] = obj[n][v];
					
					//System.out.println(obj[n][v]);
				}

			}

			int [] assign_IoT = new int [IoTs_t.length];
			for (int i = 0; i< assign_IoT.length; i++) {
				assign_IoT[i] = -1;
			}


			//System.out.println("length of IoT devices: " + IoTs_t.length);

			count = 0;
			for (int i = 0; i < assign_IoT.length; i++) {

				double max_ratio = 0; // the placement of DT with the maximum ratio of utility/consumed resource
				//int max_o_index = -1; // the index of the worker DT
				int max_v_index = -1; // the assigned cloudlet

				for (int v = 0; v < Nodes_t.length; v++) {
					if (Nodes_t[v].enough_band(IoTs_t[i]) && ratio_table[i][v] > max_ratio) {
						max_ratio = ratio_table[i][v];
						max_v_index = v;
					}
				}

				if (max_v_index != -1) { 
					count ++;
					assign_IoT[i] = max_v_index;
					Nodes_t[max_v_index].put(IoTs_t[i]);
					tot_u += obj[i][max_v_index];
					IoTs_t[i].add(DTs_t[i]);
				}
			}

			//System.out.println("number of admitted IoT devices: " + count);

			clear_band(Nodes_t);

			//System.out.println("time: " + t + ", u: "+ tot_u);


		}

		clear(Nodes_t);
		clear(IoTs_t);

		long endTime = System.currentTimeMillis();

		res result= new res (tot_u, endTime -startTime);

		return result;


		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		//for (int i = 0; i < used.length; i++) {
		//	System.out.println("cloudlet " + i +": residual: " + used[i] + ", capacity: " + Nodes_t[i].getCapacity() );
		//}
	}


	public static res gdy_u_backup(double[][] connect_map_t, double[][] cost_map_t, Node[] Nodes_t, Objectt[] IoTs_t, DT [] DTs_t, model [] models_t) {
		//heu.1

		long startTime = System.currentTimeMillis();
		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		double tot_u = 0;

		double [][] shortestD_map = new double[cost_map_t.length][cost_map_t[0].length];

		for (int i = 0; i< cost_map_t.length; i++) { //print shortest delay
			shortestD_map[i] = dijkstra_alg(i, cost_map_t).getValue();
		}

		double[][] c_DT_exp = new double [DTs_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_DT_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				for (int k = 0; k < K; k++) {
					int loc_k = loc[k];
					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[loc_k];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[loc_k][j];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[j].getProc_cost();
					c_DT_exp[i][j] += (c_upload + c_trans + c_DT_proc) / K;
				}
			}
		}


		System.out.println("gdy_u: begin to place DTs");

		int [] assign_DT = new int [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			assign_DT[i] = -1;
		}

		boolean[] admission_DT = new boolean [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			admission_DT[i] = false; // initially all DTs are not admitted;
		}


		int count = 0;
		for (int i = 0; i < assign_DT.length; i++) {

			double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
			//int max_o_index = -1; // the index of the worker DT
			int min_v_index = -1; // the assigned cloudlet

			for (int v = 0; v < Nodes_t.length; v++) {
				if (Nodes_t[v].enough(DTs_t[i]) && c_DT_exp[i][v] < min_cost) {
					min_cost = c_DT_exp[i][v];
					//max_o_index = j;
					min_v_index = v;
				}
			}
			if (min_v_index != -1) { 
				count ++;
				assign_DT[i] = min_v_index;
				Nodes_t[min_v_index].put(DTs_t[i]);
			}
		}


		System.out.println("begin to place models");
		////////////////////////// 
		// Place models

		double[][] c_m_exp = new double [models_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < models_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_m_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < models_t.length; i++) {
			int [] m_DTs_index = models_t[i].getDTs();

			for (int j = 0; j < Nodes_t.length; j++) {
				for (int k = 0; k < m_DTs_index.length; k++) {
					int DT_index = m_DTs_index[k];
					int loc_k = assign_DT[DT_index];
					double c_trans = DTs_t[DT_index].getWorker_size() * shortestD_map[loc_k][j];
					c_m_exp[i][j] += c_trans;
					double c_m_proc = DTs_t[DT_index].getWorker_size() * Nodes_t[j].getProc_cost();
					c_m_exp[i][j] += c_m_proc;
				}
			}
		}

		int [] assign_m = new int [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			assign_m[i] = -1;
		}

		boolean[] admission_m = new boolean [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			admission_m[i] = false; // initially all DTs are not admitted;
		}

		count = 0;
		for (int i = 0; i < assign_m.length; i++) {

			double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
			//int max_o_index = -1; // the index of the worker DT
			int min_v_index = -1; // the assigned cloudlet

			for (int v = 0; v < Nodes_t.length; v++) {
				if (Nodes_t[v].enough(DTs_t[i]) && c_DT_exp[i][v] < min_cost) {
					min_cost = c_DT_exp[i][v];
					//max_o_index = j;
					min_v_index = v;
				}
			}
			if (min_v_index != -1) { 
				count ++;
				assign_m[i] = min_v_index;
				Nodes_t[min_v_index].put(DTs_t[i]);
			}
		}



		for (int t = 0; t < Time_num; t++){

			//int[] IoT_loc = new int [IoTs_t.length]; 

			// initialize the profit table
			double[][] obj = new double[IoTs_t.length][Nodes_t.length];
			for (int i = 0; i < IoTs_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
					obj[i][j] = 0;
					for (int m = 0; m < models_t.length; m++) {
						int [] m_DTs_index = models_t[m].getDTs();
						int K = m_DTs_index.length;
						for (int k = 0; k < K; k++) {
							if (m_DTs_index[k] == i) {
								obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]) / K;
								//obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]);
							}
						}
					}
					//System.out.println(obj[i][j]);
				}
			}

			//for (int i = 0; i < IoTs_t.length; i++) {
			//	for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
			//		System.out.println(obj[i][j]);
			//	}
			//}


			for (int i = 0; i < IoTs_t.length; i++) {
				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				int loc_k = loc[t%K]; // the location of the IoT device at time t
				for (int j = 0; j < Nodes_t.length; j ++) {
					if (loc_k == j || connect_map_t[loc_k][j] == 1) {
						double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[j];
						double c_trans = DTs_t[i].getRaw_size() * shortestD_map[j][assign_DT[i]];
						double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[assign_DT[i]].getProc_cost();
						double c_m_trans = 0;
						double c_m_proc = 0;
						for (int m = 0; m < models_t.length; m++) {
							int [] m_DTs_index = models_t[m].getDTs();
							int KK = m_DTs_index.length;
							for (int k = 0; k < KK; k++) {
								if (m_DTs_index[k] == i) {
									c_m_trans += DTs_t[i].getWorker_size() * shortestD_map[assign_DT[i]][assign_m[m]];
									c_m_proc += DTs_t[i].getWorker_size() * Nodes_t[assign_m[m]].getProc_cost();
								}
							}
						}
						obj[i][j] -= omega * (c_upload + c_trans + c_DT_proc + c_m_trans + c_m_proc);

					}
					else {
						obj[i][j] = 0;
					}
				}
			}

			//double [][] h_table = new double [N] [Nodes_t.length]; 
			double [][] ratio_table = new double [IoTs_t.length] [Nodes_t.length]; 
			// the utility gain table, i.e., the profit table

			for (int n = 0; n < IoTs_t.length; n++) { // for each worker DT //build the tables
				for (int v = 0; v < Nodes_t.length; v++) { // for each possible placement of worker DT
					//ratio_table[n][v] = obj[n][v] / (IoTs_t[n].getBand()[v] / Nodes_t[v].getBand_cap());
					ratio_table[n][v] = obj[n][v];
				}

			}

			int [] assign_IoT = new int [IoTs_t.length];
			for (int i = 0; i< assign_IoT.length; i++) {
				assign_IoT[i] = -1;
			}


			//System.out.println("length of IoT devices: " + IoTs_t.length);

			count = 0;
			for (int i = 0; i < assign_IoT.length; i++) {

				double max_ratio = 0; // the placement of DT with the maximum ratio of utility/consumed resource
				//int max_o_index = -1; // the index of the worker DT
				int max_v_index = -1; // the assigned cloudlet

				for (int v = 0; v < Nodes_t.length; v++) {
					if (Nodes_t[v].enough_band(IoTs_t[i]) && ratio_table[i][v] > max_ratio) {
						max_ratio = ratio_table[i][v];
						max_v_index = v;
					}
				}

				if (max_v_index != -1) { 
					count ++;
					assign_IoT[i] = max_v_index;
					Nodes_t[max_v_index].put(IoTs_t[i]);
					tot_u += obj[i][max_v_index];
					IoTs_t[i].add(DTs_t[i]);
				}
			}

			//System.out.println("number of admitted IoT devices: " + count);

			clear_band(Nodes_t);

			//System.out.println("time: " + t + ", u: "+ tot_u);
		}

		clear(Nodes_t);
		clear(IoTs_t);

		long endTime = System.currentTimeMillis();

		res result= new res (tot_u, endTime -startTime);

		return result;


		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		//for (int i = 0; i < used.length; i++) {
		//	System.out.println("cloudlet " + i +": residual: " + used[i] + ", capacity: " + Nodes_t[i].getCapacity() );
		//}
	}




	public static res gdy_m(double[][] connect_map_t, double[][] cost_map_t, Node[] Nodes_t, Objectt[] IoTs_t, DT [] DTs_t, model [] models_t) {
		//heu.2

		long startTime = System.currentTimeMillis();
		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		double tot_u = 0;

		double [][] shortestD_map = new double[cost_map_t.length][cost_map_t[0].length];

		for (int i = 0; i< cost_map_t.length; i++) { //print shortest delay
			shortestD_map[i] = dijkstra_alg(i, cost_map_t).getValue();
		}

		double[][] c_DT_exp = new double [DTs_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_DT_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {

				c_DT_exp[i][j] += DTs_t[i].getConsump() * instantiation_ratio;

				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				for (int k = 0; k < K; k++) {
					int loc_k = loc[k];
					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[loc_k];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[loc_k][j];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[j].getProc_cost();
					c_DT_exp[i][j] += (c_upload + c_trans + c_DT_proc) / K;
				}
			}
		}


		System.out.println("gdy_u: begin to place DTs");

		int [] assign_DT = new int [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			assign_DT[i] = -1;
		}

		boolean[] admission_DT = new boolean [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			admission_DT[i] = false; // initially all DTs are not admitted;
		}


		int count = 0;
		for (int v = 0; v < Nodes_t.length; v++) {

			for (int ii = 0; ii < assign_DT.length; ii++) {

				double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
				//int max_o_index = -1; // the index of the worker DT
				int min_i_index = -1; // the assigned cloudlet

				boolean flaggg = true; // the cloudlet can hold any more

				if (flaggg){
					for (int i = 0; i < assign_DT.length; i++) {
						if (Nodes_t[v].enough(DTs_t[i]) && c_DT_exp[i][v] < min_cost && assign_DT[i] == -1) {
							min_cost = c_DT_exp[i][v];
							//max_o_index = j;
							min_i_index = i;
						}
					}
					if (min_i_index != -1) { 

						tot_u += c_DT_exp[min_i_index][v];

						count ++;
						assign_DT[min_i_index] = v;
						Nodes_t[v].put(DTs_t[min_i_index]);
					}
					else {
						flaggg = false;
					}
				}
				else {
					break;
				}

			}
		}


		System.out.println("begin to place models");
		////////////////////////// 
		// Place models

		double[][] c_m_exp = new double [models_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < models_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_m_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < models_t.length; i++) {
			int [] m_DTs_index = models_t[i].getDTs();

			for (int j = 0; j < Nodes_t.length; j++) {

				c_m_exp[i][j] += models_t[i].getConsump() * instantiation_ratio;

				for (int k = 0; k < m_DTs_index.length; k++) {
					int DT_index = m_DTs_index[k];
					int loc_k = assign_DT[DT_index];
					double c_trans = DTs_t[DT_index].getWorker_size() * shortestD_map[loc_k][j];
					c_m_exp[i][j] += c_trans;
					double c_m_proc = DTs_t[DT_index].getWorker_size() * Nodes_t[j].getProc_cost();
					c_m_exp[i][j] += c_m_proc;
				}
			}
		}

		int [] assign_m = new int [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			assign_m[i] = -1;
		}

		boolean[] admission_m = new boolean [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			admission_m[i] = false; // initially all DTs are not admitted;
		}

		count = 0;
		for (int v = 0; v < Nodes_t.length; v++) {

			for (int ii = 0; ii < assign_m.length; ii++) {

				boolean flaggg = true;

				if (flaggg){

					double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
					//int max_o_index = -1; // the index of the worker DT
					int min_i_index = -1; // the assigned cloudlet

					for (int i = 0; i < assign_m.length; i++) {
						if (Nodes_t[v].enough(models_t[i]) && c_m_exp[i][v] < min_cost && assign_m[i] == -1) {
							min_cost = c_m_exp[i][v];
							//max_o_index = j;
							min_i_index = i;
						}
					}
					if (min_i_index != -1) { 

						tot_u += c_m_exp[min_i_index][v];

						count ++;
						assign_m[min_i_index] = v;
						Nodes_t[v].put(models_t[min_i_index]);
					}
					else {
						flaggg = false;
					}
				}
				else {
					break;
				}
			}
		}



		clear(Nodes_t);
		clear(IoTs_t);

		long endTime = System.currentTimeMillis();

		res result= new res (tot_u, endTime -startTime);

		return result;


		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		//for (int i = 0; i < used.length; i++) {
		//	System.out.println("cloudlet " + i +": residual: " + used[i] + ", capacity: " + Nodes_t[i].getCapacity() );
		//}
	}
	
	


	public static res gdy_m_2(double[][] connect_map_t, double[][] cost_map_t, Node[] Nodes_t, Objectt[] IoTs_t, DT [] DTs_t, model [] models_t) {
		//heu.2

		long startTime = System.currentTimeMillis();
		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		double tot_u = 0;

		double [][] shortestD_map = new double[cost_map_t.length][cost_map_t[0].length];

		for (int i = 0; i< cost_map_t.length; i++) { //print shortest delay
			shortestD_map[i] = dijkstra_alg(i, cost_map_t).getValue();
		}

		double[][] c_DT_exp = new double [DTs_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_DT_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {

				c_DT_exp[i][j] += DTs_t[i].getConsump() * instantiation_ratio;

				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				for (int k = 0; k < K; k++) {
					int loc_k = loc[k];
					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[loc_k];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[loc_k][j];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[j].getProc_cost();
					c_DT_exp[i][j] += (c_upload + c_trans + c_DT_proc) / K;
				}
			}
		}


		System.out.println("gdy_u: begin to place DTs");

		int [] assign_DT = new int [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			assign_DT[i] = -1;
		}

		boolean[] admission_DT = new boolean [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			admission_DT[i] = false; // initially all DTs are not admitted;
		}


		int count = 0;
		for (int v = 0; v < Nodes_t.length; v++) {

			for (int ii = 0; ii < assign_DT.length; ii++) {

				double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
				//int max_o_index = -1; // the index of the worker DT
				int min_i_index = -1; // the assigned cloudlet

				boolean flaggg = true; // the cloudlet can hold any more

				if (flaggg){
					for (int i = 0; i < assign_DT.length; i++) {
						if (Nodes_t[v].enough(DTs_t[i]) && c_DT_exp[i][v] < min_cost && assign_DT[i] == -1) {
							min_cost = c_DT_exp[i][v];
							//max_o_index = j;
							min_i_index = i;
						}
					}
					if (min_i_index != -1) { 

						//tot_u += c_DT_exp[min_i_index][v];

						count ++;
						assign_DT[min_i_index] = v;
						Nodes_t[v].put(DTs_t[min_i_index]);
					}
					else {
						flaggg = false;
					}
				}
				else {
					break;
				}

			}
		}


		System.out.println("begin to place models");
		////////////////////////// 
		// Place models

		double[][] c_m_exp = new double [models_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < models_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_m_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < models_t.length; i++) {
			int [] m_DTs_index = models_t[i].getDTs();

			for (int j = 0; j < Nodes_t.length; j++) {

				c_m_exp[i][j] += models_t[i].getConsump() * instantiation_ratio;

				for (int k = 0; k < m_DTs_index.length; k++) {
					int DT_index = m_DTs_index[k];
					int loc_k = assign_DT[DT_index];
					double c_trans = DTs_t[DT_index].getWorker_size() * shortestD_map[loc_k][j];
					c_m_exp[i][j] += c_trans;
					double c_m_proc = DTs_t[DT_index].getWorker_size() * Nodes_t[j].getProc_cost();
					c_m_exp[i][j] += c_m_proc;
				}
			}
		}

		int [] assign_m = new int [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			assign_m[i] = -1;
		}

		boolean[] admission_m = new boolean [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			admission_m[i] = false; // initially all DTs are not admitted;
		}

		count = 0;
		for (int v = 0; v < Nodes_t.length; v++) {

			for (int ii = 0; ii < assign_m.length; ii++) {

				boolean flaggg = true;

				if (flaggg){

					double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
					//int max_o_index = -1; // the index of the worker DT
					int min_i_index = -1; // the assigned cloudlet

					for (int i = 0; i < assign_m.length; i++) {
						if (Nodes_t[v].enough(models_t[i]) && c_m_exp[i][v] < min_cost && assign_m[i] == -1) {
							min_cost = c_m_exp[i][v];
							//max_o_index = j;
							min_i_index = i;
						}
					}
					if (min_i_index != -1) { 

						//tot_u += c_m_exp[min_i_index][v];

						count ++;
						assign_m[min_i_index] = v;
						Nodes_t[v].put(models_t[min_i_index]);
					}
					else {
						flaggg = false;
					}
				}
				else {
					break;
				}
			}
		}



		for (int t = 0; t < Time_num; t++){

			//int[] IoT_loc = new int [IoTs_t.length]; 

			// initialize the profit table
			double[][] obj = new double[IoTs_t.length][Nodes_t.length];
			for (int i = 0; i < IoTs_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
					obj[i][j] = 0;
					for (int m = 0; m < models_t.length; m++) {
						int [] m_DTs_index = models_t[m].getDTs();
						int K = m_DTs_index.length;
						for (int k = 0; k < K; k++) {
							if (m_DTs_index[k] == i) {
								obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]) / K;
								//obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]);
							}
						}
					}
					//System.out.println(obj[i][j]);
				}
			}

			//for (int i = 0; i < IoTs_t.length; i++) {
			//	for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
			//		System.out.println(obj[i][j]);
			//	}
			//}


			for (int i = 0; i < IoTs_t.length; i++) {
				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				int loc_k = loc[t%K]; // the location of the IoT device at time t
				for (int j = 0; j < Nodes_t.length; j ++) {
					if (loc_k == j || connect_map_t[loc_k][j] == 1) {
						double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[j];
						double c_trans = DTs_t[i].getRaw_size() * shortestD_map[j][assign_DT[i]];
						double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[assign_DT[i]].getProc_cost();
						double c_m_trans = 0;
						double c_m_proc = 0;
						for (int m = 0; m < models_t.length; m++) {
							int [] m_DTs_index = models_t[m].getDTs();
							int KK = m_DTs_index.length;
							for (int k = 0; k < KK; k++) {
								if (m_DTs_index[k] == i) {
									c_m_trans += DTs_t[i].getWorker_size() * shortestD_map[assign_DT[i]][assign_m[m]];
									c_m_proc += DTs_t[i].getWorker_size() * Nodes_t[assign_m[m]].getProc_cost();
								}
							}
						}
						obj[i][j] -= omega * (c_upload + c_trans + c_DT_proc + c_m_trans + c_m_proc);

					}
					else {
						obj[i][j] = 0;
					}
				}
			}

			//double [][] h_table = new double [N] [Nodes_t.length]; 
			double [][] ratio_table = new double [IoTs_t.length] [Nodes_t.length]; 
			// the utility gain table, i.e., the profit table

			for (int n = 0; n < IoTs_t.length; n++) { // for each worker DT //build the tables
				for (int v = 0; v < Nodes_t.length; v++) { // for each possible placement of worker DT
					//ratio_table[n][v] = obj[n][v] / (IoTs_t[n].getBand()[v] / Nodes_t[v].getBand_cap());
					ratio_table[n][v] = obj[n][v];
				}

			}

			int [] assign_IoT = new int [IoTs_t.length];
			for (int i = 0; i< assign_IoT.length; i++) {
				assign_IoT[i] = -1;
			}


			//System.out.println("length of IoT devices: " + IoTs_t.length);

			boolean[] admission_IoT = new boolean [IoTs_t.length];
			for (int i = 0; i < IoTs_t.length; i++) {
				admission_IoT[i] = false; // initially all DTs are not admitted;
			}

			count = 0;

			for (int v = 0; v < Nodes_t.length; v++) {
				int band_cap = (int)Nodes_t[v].getBand_cap();
				for (int r = 0; r < band_cap; r++) {
					double max_ratio = 0; // the placement of DT with the maximum ratio of utility/consumed resource
					int max_o_index = -1; // the index of the worker DT
					//int max_v_index = -1; // the assigned cloudlet
					for (int i = 0; i < assign_IoT.length; i++) {
						if (admission_IoT[i] == false && ratio_table[i][v] > max_ratio) {
							max_ratio = ratio_table[i][v];
							max_o_index = i;
						}
					}

					if (max_o_index != -1) { 
						count ++;
						assign_IoT[max_o_index] = v;
						admission_IoT[max_o_index] = true;
						Nodes_t[v].put(IoTs_t[max_o_index]);

						//if (Nodes_t[v].getResi_band () < 0) {
						//System.out.println("Out of band!!!!!!!!!!!!!!!!!!!!");
						//}
						tot_u += obj[max_o_index][v];
						IoTs_t[max_o_index].add(DTs_t[max_o_index]);
					}
				}
			}


			//System.out.println("number of admitted IoT devices: " + count);

			clear_band(Nodes_t);

			//System.out.println("time: " + t + ", u: "+ tot_u);
		}

		clear(Nodes_t);
		clear(IoTs_t);

		long endTime = System.currentTimeMillis();

		res result= new res (tot_u, endTime -startTime);

		return result;


		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		//for (int i = 0; i < used.length; i++) {
		//	System.out.println("cloudlet " + i +": residual: " + used[i] + ", capacity: " + Nodes_t[i].getCapacity() );
		//}
	}



	
	public static res gdy_m_3(double[][] connect_map_t, double[][] cost_map_t, Node[] Nodes_t, Objectt[] IoTs_t, DT [] DTs_t, model [] models_t) {
		//heu.2

		long startTime = System.currentTimeMillis();
		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		double tot_u = 0;

		double [][] shortestD_map = new double[cost_map_t.length][cost_map_t[0].length];

		for (int i = 0; i< cost_map_t.length; i++) { //print shortest delay
			shortestD_map[i] = dijkstra_alg(i, cost_map_t).getValue();
		}

		double[][] c_DT_exp = new double [DTs_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_DT_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {

				c_DT_exp[i][j] += DTs_t[i].getConsump() * instantiation_ratio;

				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				for (int k = 0; k < K; k++) {
					int loc_k = loc[k];
					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[loc_k];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[loc_k][j];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[j].getProc_cost();
					c_DT_exp[i][j] += (c_upload + c_trans + c_DT_proc) / K;
				}
			}
		}


		System.out.println("gdy_u: begin to place DTs");

		int [] assign_DT = new int [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			assign_DT[i] = -1;
		}

		for (int v = 0; v < Nodes_t.length; v++) {

			for (int ii = 0; ii < assign_DT.length; ii++) {

				double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
				//int max_o_index = -1; // the index of the worker DT
				int min_i_index = -1; // the assigned cloudlet

				boolean flaggg = true; // the cloudlet can hold any more

				if (flaggg){
					for (int i = 0; i < assign_DT.length; i++) {
						if (Nodes_t[v].enough(DTs_t[i]) && c_DT_exp[i][v] < min_cost && assign_DT[i] == -1) {
							min_cost = c_DT_exp[i][v];
							//max_o_index = j;
							min_i_index = i;
						}
					}
					if (min_i_index != -1) { 

						//tot_u += c_DT_exp[min_i_index][v];
						assign_DT[min_i_index] = v;
						Nodes_t[v].put(DTs_t[min_i_index]);
					}
					else {
						flaggg = false;
					}
				}
				else {
					break;
				}

			}
		}


		System.out.println("begin to place models");
		////////////////////////// 
		// Place models

		double[][] c_m_exp = new double [models_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < models_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_m_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < models_t.length; i++) {
			int [] m_DTs_index = models_t[i].getDTs();

			for (int j = 0; j < Nodes_t.length; j++) {

				c_m_exp[i][j] += models_t[i].getConsump() * instantiation_ratio;

				for (int k = 0; k < m_DTs_index.length; k++) {
					int DT_index = m_DTs_index[k];
					int loc_k = assign_DT[DT_index];
					double c_trans = DTs_t[DT_index].getWorker_size() * shortestD_map[loc_k][j];
					c_m_exp[i][j] += c_trans;
					double c_m_proc = DTs_t[DT_index].getWorker_size() * Nodes_t[j].getProc_cost();
					c_m_exp[i][j] += c_m_proc;
				}
			}
		}

		int [] assign_m = new int [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			assign_m[i] = -1;
		}

		for (int v = 0; v < Nodes_t.length; v++) {

			for (int ii = 0; ii < assign_m.length; ii++) {

				boolean flaggg = true;

				if (flaggg){

					double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
					//int max_o_index = -1; // the index of the worker DT
					int min_i_index = -1; // the assigned cloudlet

					for (int i = 0; i < assign_m.length; i++) {
						if (Nodes_t[v].enough(models_t[i]) && c_m_exp[i][v] < min_cost && assign_m[i] == -1) {
							min_cost = c_m_exp[i][v];
							//max_o_index = j;
							min_i_index = i;
						}
					}
					if (min_i_index != -1) { 

						//tot_u += c_m_exp[min_i_index][v];

						assign_m[min_i_index] = v;
						Nodes_t[v].put(models_t[min_i_index]);
					}
					else {
						flaggg = false;
					}
				}
				else {
					break;
				}
			}
		}



		for (int t = 0; t < Time_num; t++){

			clear(Nodes_t);
			//clear(IoTs_t);

			//////////////////
			//migrations

			//migrate DTs

			double[][] new_c_DT_exp = new double [DTs_t.length][Nodes_t.length]; // cost of offloading k to v
			for (int i = 0; i < DTs_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j++) {
					new_c_DT_exp[i][j] = 0;
				}
			}

			for (int i = 0; i < DTs_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j++) {

					if (assign_DT[i]!= j) {
						new_c_DT_exp[i][j] += DTs_t[i].getConsump() * instantiation_ratio;
						new_c_DT_exp[i][j] += IoTs_t[i].getCollected() * migration_ratio * shortestD_map[assign_DT[i]][j];
					}

					int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
					int K = loc.length;
					int loc_k = loc[t%K]; // the location of the IoT device at time t

					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[loc_k];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[loc_k][j];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[j].getProc_cost();
					new_c_DT_exp[i][j] += (c_upload + c_trans + c_DT_proc);
				}
			}

			int [] new_assign_DT = new int [DTs_t.length];
			for (int i = 0; i < DTs_t.length; i++) {
				new_assign_DT[i] = -1;
			}

			for (int v = 0; v < Nodes_t.length; v++) {

				for (int ii = 0; ii < new_assign_DT.length; ii++) {

					double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
					//int max_o_index = -1; // the index of the worker DT
					int min_i_index = -1; // the assigned cloudlet

					boolean flaggg = true; // the cloudlet can hold any more

					if (flaggg){
						for (int i = 0; i < new_assign_DT.length; i++) {
							if (Nodes_t[v].enough(DTs_t[i]) && new_c_DT_exp[i][v] < min_cost && new_assign_DT[i] == -1) {
								min_cost = new_c_DT_exp[i][v];
								//max_o_index = j;
								min_i_index = i;
							}
						}
						if (min_i_index != -1) { 

							//tot_u += c_DT_exp[min_i_index][v];

							new_assign_DT[min_i_index] = v;
							Nodes_t[v].put(DTs_t[min_i_index]);
						}
						else {
							flaggg = false;
						}
					}
					else {
						break;
					}

				}
			}

			//&&&&&&&&&&&&&&&&&&&&&&&
			for (int i = 0; i < DTs_t.length; i++) {
				if(assign_DT[i] != new_assign_DT[i]) {
					tot_u -= omega * DTs_t[i].getConsump() * instantiation_ratio;
					tot_u -= omega * IoTs_t[i].getCollected() * migration_ratio * shortestD_map[assign_DT[i]][new_assign_DT[i]];
					assign_DT[i] = new_assign_DT[i];
				}
			}



			//migrate models

			double[][] new_c_m_exp = new double [models_t.length][Nodes_t.length]; // cost of offloading k to v
			for (int i = 0; i < models_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j++) {
					new_c_m_exp[i][j] = 0;
				}
			}

			for (int i = 0; i < models_t.length; i++) {
				int [] m_DTs_index = models_t[i].getDTs();

				for (int j = 0; j < Nodes_t.length; j++) {

					if (assign_m[i]!= j) {
						new_c_m_exp[i][j] += models_t[i].getConsump() * instantiation_ratio;
						new_c_m_exp[i][j] += models_t[i].getModelSize() * migration_ratio * shortestD_map[assign_m[i]][j];
					}

					for (int k = 0; k < m_DTs_index.length; k++) {
						int DT_index = m_DTs_index[k];
						int loc_k = assign_DT[DT_index];
						double c_trans = DTs_t[DT_index].getWorker_size() * shortestD_map[loc_k][j];
						new_c_m_exp[i][j] += c_trans;
						double c_m_proc = DTs_t[DT_index].getWorker_size() * Nodes_t[j].getProc_cost();
						new_c_m_exp[i][j] += c_m_proc;
					}
				}
			}

			int [] new_assign_m = new int [models_t.length];
			for (int i = 0; i < models_t.length; i++) {
				new_assign_m[i] = -1;
			}


			for (int v = 0; v < Nodes_t.length; v++) {

				for (int ii = 0; ii < new_assign_m.length; ii++) {

					boolean flaggg = true;

					if (flaggg){

						double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
						//int max_o_index = -1; // the index of the worker DT
						int min_i_index = -1; // the assigned cloudlet

						for (int i = 0; i < new_assign_m.length; i++) {
							if (Nodes_t[v].enough(models_t[i]) && new_c_m_exp[i][v] < min_cost && new_assign_m[i] == -1) {
								min_cost = new_c_m_exp[i][v];
								//max_o_index = j;
								min_i_index = i;
							}
						}
						if (min_i_index != -1) { 

							//tot_u += c_m_exp[min_i_index][v];

							new_assign_m[min_i_index] = v;
							Nodes_t[v].put(models_t[min_i_index]);
						}
						else {
							flaggg = false;
						}
					}
					else {
						break;
					}
				}
			}


			//&&&&&&&&&&&&&&&&&&&&&&&
			for (int i = 0; i < assign_m.length; i++) {
				if(assign_m[i] != new_assign_m[i]) {
					tot_u -= omega * models_t[i].getConsump() * instantiation_ratio;;
					tot_u -= omega * models_t[i].getModelSize() * migration_ratio * shortestD_map[assign_m[i]][new_assign_m[i]];
					assign_m[i] = new_assign_m[i];
				}
			}

			//int[] IoT_loc = new int [IoTs_t.length]; 

			// initialize the profit table
			double[][] obj = new double[IoTs_t.length][Nodes_t.length];
			for (int i = 0; i < IoTs_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
					obj[i][j] = 0;
					for (int m = 0; m < models_t.length; m++) {
						int [] m_DTs_index = models_t[m].getDTs();
						int K = m_DTs_index.length;
						for (int k = 0; k < K; k++) {
							if (m_DTs_index[k] == i) {
								obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]) / K;
								//obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]);
							}
						}
					}
					//System.out.println(obj[i][j]);
				}
			}

			//for (int i = 0; i < IoTs_t.length; i++) {
			//	for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
			//		System.out.println(obj[i][j]);
			//	}
			//}


			for (int i = 0; i < IoTs_t.length; i++) {
				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				int loc_k = loc[t%K]; // the location of the IoT device at time t
				for (int j = 0; j < Nodes_t.length; j ++) {
					if (loc_k == j || connect_map_t[loc_k][j] == 1) {
						double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[j];
						double c_trans = DTs_t[i].getRaw_size() * shortestD_map[j][assign_DT[i]];
						double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[assign_DT[i]].getProc_cost();
						double c_m_trans = 0;
						double c_m_proc = 0;
						for (int m = 0; m < models_t.length; m++) {
							int [] m_DTs_index = models_t[m].getDTs();
							int KK = m_DTs_index.length;
							for (int k = 0; k < KK; k++) {
								if (m_DTs_index[k] == i) {
									c_m_trans += DTs_t[i].getWorker_size() * shortestD_map[assign_DT[i]][assign_m[m]];
									c_m_proc += DTs_t[i].getWorker_size() * Nodes_t[assign_m[m]].getProc_cost();
								}
							}
						}
						obj[i][j] -= omega * (c_upload + c_trans + c_DT_proc + c_m_trans + c_m_proc);

					}
					else {
						obj[i][j] = 0;
					}
				}
			}

			//double [][] h_table = new double [N] [Nodes_t.length]; 
			double [][] ratio_table = new double [IoTs_t.length] [Nodes_t.length]; 
			// the utility gain table, i.e., the profit table

			for (int n = 0; n < IoTs_t.length; n++) { // for each worker DT //build the tables
				for (int v = 0; v < Nodes_t.length; v++) { // for each possible placement of worker DT
					//ratio_table[n][v] = obj[n][v] / (IoTs_t[n].getBand()[v] / Nodes_t[v].getBand_cap());
					ratio_table[n][v] = obj[n][v];
				}

			}

			int [] assign_IoT = new int [IoTs_t.length];
			for (int i = 0; i< assign_IoT.length; i++) {
				assign_IoT[i] = -1;
			}


			//System.out.println("length of IoT devices: " + IoTs_t.length);

			boolean[] admission_IoT = new boolean [IoTs_t.length];
			for (int i = 0; i < IoTs_t.length; i++) {
				admission_IoT[i] = false; // initially all DTs are not admitted;
			}


			for (int v = 0; v < Nodes_t.length; v++) {
				int band_cap = (int)Nodes_t[v].getBand_cap();
				for (int r = 0; r < band_cap; r++) {
					double max_ratio = 0; // the placement of DT with the maximum ratio of utility/consumed resource
					int max_o_index = -1; // the index of the worker DT
					//int max_v_index = -1; // the assigned cloudlet
					for (int i = 0; i < assign_IoT.length; i++) {
						if (admission_IoT[i] == false && ratio_table[i][v] > max_ratio) {
							max_ratio = ratio_table[i][v];
							max_o_index = i;
						}
					}

					if (max_o_index != -1) { 
						assign_IoT[max_o_index] = v;
						admission_IoT[max_o_index] = true;
						Nodes_t[v].put(IoTs_t[max_o_index]);

						//if (Nodes_t[v].getResi_band () < 0) {
						//System.out.println("Out of band!!!!!!!!!!!!!!!!!!!!");
						//}
						tot_u += obj[max_o_index][v];
						IoTs_t[max_o_index].add(DTs_t[max_o_index]);
					}
				}
			}


			//System.out.println("number of admitted IoT devices: " + count);

			clear_band(Nodes_t);

			//System.out.println("time: " + t + ", u: "+ tot_u);
		}

		clear(Nodes_t);
		clear(IoTs_t);

		long endTime = System.currentTimeMillis();

		res result= new res (tot_u, endTime -startTime);

		return result;


		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		//for (int i = 0; i < used.length; i++) {
		//	System.out.println("cloudlet " + i +": residual: " + used[i] + ", capacity: " + Nodes_t[i].getCapacity() );
		//}
	}



	public static res gdy_m_backup(double[][] connect_map_t, double[][] cost_map_t, Node[] Nodes_t, Objectt[] IoTs_t, DT [] DTs_t, model [] models_t) {
		//heu.2

		long startTime = System.currentTimeMillis();
		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		double tot_u = 0;

		double [][] shortestD_map = new double[cost_map_t.length][cost_map_t[0].length];

		for (int i = 0; i< cost_map_t.length; i++) { //print shortest delay
			shortestD_map[i] = dijkstra_alg(i, cost_map_t).getValue();
		}

		double[][] c_DT_exp = new double [DTs_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_DT_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < DTs_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				for (int k = 0; k < K; k++) {
					int loc_k = loc[k];
					double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[loc_k];
					double c_trans = DTs_t[i].getRaw_size() * shortestD_map[loc_k][j];
					double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[j].getProc_cost();
					c_DT_exp[i][j] += (c_upload + c_trans + c_DT_proc) / K;
				}
			}
		}


		System.out.println("gdy_u: begin to place DTs");

		int [] assign_DT = new int [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			assign_DT[i] = -1;
		}

		boolean[] admission_DT = new boolean [DTs_t.length];
		for (int i = 0; i < DTs_t.length; i++) {
			admission_DT[i] = false; // initially all DTs are not admitted;
		}


		int count = 0;
		for (int i = 0; i < assign_DT.length; i++) {

			double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
			//int max_o_index = -1; // the index of the worker DT
			int min_v_index = -1; // the assigned cloudlet

			for (int v = 0; v < Nodes_t.length; v++) {
				if (Nodes_t[v].enough(DTs_t[i]) && c_DT_exp[i][v] < min_cost) {
					min_cost = c_DT_exp[i][v];
					//max_o_index = j;
					min_v_index = v;
				}
			}
			if (min_v_index != -1) { 
				count ++;
				assign_DT[i] = min_v_index;
				Nodes_t[min_v_index].put(DTs_t[i]);
			}
		}


		System.out.println("begin to place models");
		////////////////////////// 
		// Place models

		double[][] c_m_exp = new double [models_t.length][Nodes_t.length]; // cost of offloading k to v
		for (int i = 0; i < models_t.length; i++) {
			for (int j = 0; j < Nodes_t.length; j++) {
				c_m_exp[i][j] = 0;
			}
		}

		for (int i = 0; i < models_t.length; i++) {
			int [] m_DTs_index = models_t[i].getDTs();

			for (int j = 0; j < Nodes_t.length; j++) {
				for (int k = 0; k < m_DTs_index.length; k++) {
					int DT_index = m_DTs_index[k];
					int loc_k = assign_DT[DT_index];
					double c_trans = DTs_t[DT_index].getWorker_size() * shortestD_map[loc_k][j];
					c_m_exp[i][j] += c_trans;
					double c_m_proc = DTs_t[DT_index].getWorker_size() * Nodes_t[j].getProc_cost();
					c_m_exp[i][j] += c_m_proc;
				}
			}
		}

		int [] assign_m = new int [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			assign_m[i] = -1;
		}

		boolean[] admission_m = new boolean [models_t.length];
		for (int i = 0; i < models_t.length; i++) {
			admission_m[i] = false; // initially all DTs are not admitted;
		}

		count = 0;
		for (int i = 0; i < assign_m.length; i++) {

			double min_cost = large; // the placement of DT with the maximum ratio of utility/consumed resource
			//int max_o_index = -1; // the index of the worker DT
			int min_v_index = -1; // the assigned cloudlet

			for (int v = 0; v < Nodes_t.length; v++) {
				if (Nodes_t[v].enough(DTs_t[i]) && c_DT_exp[i][v] < min_cost) {
					min_cost = c_DT_exp[i][v];
					//max_o_index = j;
					min_v_index = v;
				}
			}
			if (min_v_index != -1) { 
				count ++;
				assign_m[i] = min_v_index;
				Nodes_t[min_v_index].put(models_t[i]);
			}
		}



		for (int t = 0; t < Time_num; t++){

			//int[] IoT_loc = new int [IoTs_t.length]; 

			// initialize the profit table
			double[][] obj = new double[IoTs_t.length][Nodes_t.length];
			for (int i = 0; i < IoTs_t.length; i++) {
				for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
					obj[i][j] = 0;
					for (int m = 0; m < models_t.length; m++) {
						int [] m_DTs_index = models_t[m].getDTs();
						int K = m_DTs_index.length;
						for (int k = 0; k < K; k++) {
							if (m_DTs_index[k] == i) {
								obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]) / K;
								//obj[i][j] += cal_U(DTs_t[i].getRaw_size(), IoTs_t[i]);
							}
						}
					}
					//System.out.println(obj[i][j]);
				}
			}

			//for (int i = 0; i < IoTs_t.length; i++) {
			//	for (int j = 0; j < Nodes_t.length; j ++) { // for each assigned AP for data uploading
			//		System.out.println(obj[i][j]);
			//	}
			//}


			for (int i = 0; i < IoTs_t.length; i++) {
				int [] loc = DTs_t[i].getLoc(); // the visiting location, i.e., the uploading AP
				int K = loc.length;
				int loc_k = loc[t%K]; // the location of the IoT device at time t
				for (int j = 0; j < Nodes_t.length; j ++) {
					if (loc_k == j || connect_map_t[loc_k][j] == 1) {
						double c_upload = IoTs_t[i].getPower_cost() * IoTs_t[i].getTransPower() * DTs_t[i].getRaw_size() / IoTs_t[i].getBand()[j];
						double c_trans = DTs_t[i].getRaw_size() * shortestD_map[j][assign_DT[i]];
						double c_DT_proc = DTs_t[i].getRaw_size() * Nodes_t[assign_DT[i]].getProc_cost();
						double c_m_trans = 0;
						double c_m_proc = 0;
						for (int m = 0; m < models_t.length; m++) {
							int [] m_DTs_index = models_t[m].getDTs();
							int KK = m_DTs_index.length;
							for (int k = 0; k < KK; k++) {
								if (m_DTs_index[k] == i) {
									c_m_trans += DTs_t[i].getWorker_size() * shortestD_map[assign_DT[i]][assign_m[m]];
									c_m_proc += DTs_t[i].getWorker_size() * Nodes_t[assign_m[m]].getProc_cost();
								}
							}
						}
						obj[i][j] -= omega * (c_upload + c_trans + c_DT_proc + c_m_trans + c_m_proc);

					}
					else {
						obj[i][j] = 0;
					}
				}
			}

			//double [][] h_table = new double [N] [Nodes_t.length]; 
			double [][] ratio_table = new double [IoTs_t.length] [Nodes_t.length]; 
			// the utility gain table, i.e., the profit table

			for (int n = 0; n < IoTs_t.length; n++) { // for each worker DT //build the tables
				for (int v = 0; v < Nodes_t.length; v++) { // for each possible placement of worker DT
					//ratio_table[n][v] = obj[n][v] / (IoTs_t[n].getBand()[v] / Nodes_t[v].getBand_cap());
					ratio_table[n][v] = obj[n][v];
				}

			}

			int [] assign_IoT = new int [IoTs_t.length];
			for (int i = 0; i< assign_IoT.length; i++) {
				assign_IoT[i] = -1;
			}


			//System.out.println("length of IoT devices: " + IoTs_t.length);

			boolean[] admission_IoT = new boolean [IoTs_t.length];
			for (int i = 0; i < IoTs_t.length; i++) {
				admission_IoT[i] = false; // initially all DTs are not admitted;
			}

			count = 0;

			for (int v = 0; v < Nodes_t.length; v++) {
				int band_cap = (int)Nodes_t[v].getBand_cap();
				for (int r = 0; r < band_cap; r++) {
					double max_ratio = 0; // the placement of DT with the maximum ratio of utility/consumed resource
					int max_o_index = -1; // the index of the worker DT
					//int max_v_index = -1; // the assigned cloudlet
					for (int i = 0; i < assign_IoT.length; i++) {
						if (admission_IoT[i] == false && ratio_table[i][v] > max_ratio) {
							max_ratio = ratio_table[i][v];
							max_o_index = i;
						}
					}

					if (max_o_index != -1) { 
						count ++;
						assign_IoT[max_o_index] = v;
						admission_IoT[max_o_index] = true;
						Nodes_t[v].put(IoTs_t[max_o_index]);

						//if (Nodes_t[v].getResi_band () < 0) {
						//System.out.println("Out of band!!!!!!!!!!!!!!!!!!!!");
						//}
						tot_u += obj[max_o_index][v];
						IoTs_t[max_o_index].add(DTs_t[max_o_index]);
					}
				}
			}


			//System.out.println("number of admitted IoT devices: " + count);

			clear_band(Nodes_t);

			//System.out.println("time: " + t + ", u: "+ tot_u);
		}

		clear(Nodes_t);
		clear(IoTs_t);

		long endTime = System.currentTimeMillis();

		res result= new res (tot_u, endTime -startTime);

		return result;


		//for (int v = 0; v < Nodes_t.length; v++) {
		//	Nodes_t[v].clear();
		//}

		//for (int i = 0; i < used.length; i++) {
		//	System.out.println("cloudlet " + i +": residual: " + used[i] + ", capacity: " + Nodes_t[i].getCapacity() );
		//}
	}

	
	
	public static void DiffNumOfNodes () {

		String alg01_utility = new String();
		String opt_utility = new String();
		String gdy_u_utility = new String();
		String gdy_m_utility = new String();

		String alg02_utility = new String();
		String alg03_utility = new String();
		String opt_on_utility = new String();
		String gdy_u_on_utility = new String();
		String gdy_m_on_utility = new String();

		//*****************************************

		String alg01_time = new String();
		String opt_time = new String();
		String gdy_u_time = new String();
		String gdy_m_time = new String();

		String alg02_time = new String();
		String alg03_time = new String();
		String gdy_u_on_time = new String();
		String gdy_m_on_time = new String();

		//*****************************************

		String alg01_logtime = new String();
		String gdy_u_logtime = new String();
		String gdy_m_logtime = new String();
		String opt_logtime = new String();

		String alg02_logtime = new String();
		String alg03_logtime = new String();
		String gdy_u_on_logtime = new String();
		String gdy_m_on_logtime = new String();

		//*****************************************

		for (int k=1; k< 6; k ++) { // num_cloudlets********************
		//for (int k=2; k< 6; k ++) { // num_cloudlets********************
		//for (int k=1; k< 2; k ++) { // num_cloudlets********************
			//for (int k=5; k< 6; k ++) {
			int num_cloudlets = k *5;

			int Node_size_k = num_cloudlets * 10;
			double [][] connect_map_k = new double[Node_size_k][Node_size_k];
			connect_map_k = readTxtFileIntoStringArrList("C:/Markov/"+Node_size_k +".txt", Node_size_k );
			double[][] cost_map_k = new double[Node_size_k][Node_size_k];

			for (int i =0 ; i<Node_size_k ; i ++) {
				for (int j = 0; j < i; j++ ) {
					if (connect_map_k[i][j] == 1) {
						cost_map_k[i][j] = getRandomValue (0.01, 0.1); //0.01 - 0.1 
						//System.out.println(cost_map_k[i][j]);
					}
					else {
						cost_map_k[i][j] = M;
						cost_map_k[j][i] = M;
					}
				}
				cost_map_k[i][i] = 0;
			}


			Node [] Nodes_k = new Node[Node_size_k];
			for (int i = 0; i < Node_size_k; i++) {
				//Node (int id, int capacity)

				double capacity =  getRandomValue (4000, 8000);

				double band_cap = getRandomIntValue (3, 6); // the number of subchannels// 3-6
				//System.out.println (band_cap);

				double bandwidth = getRandomValue (5, 20);
				//System.out.println (bandwidth);

				double proc_cost = getRandomValue (0.01, 0.1);

				Nodes_k[i] = new Node(i, capacity, band_cap, bandwidth, proc_cost); 
				//int id, double capacity, double band
				//capacity: 4,000$ MHz to 8,000$ MHz, 
			}

			///////////////////


			Objectt [] IoTs_k = new Objectt [IoT_size];

			for (int i = 0; i < IoT_size; i++) {
				//double band_i = 100 + 128*(i%8); // 128 - 1024 MHz

				double transPower = getRandomValue (0.1, 0.5);

				double channelGain = Math.pow(10,6) / Math.pow(5,4); // it is channelGain / noise, distance set as 50, i.e, 50^(-4)/ 10^10 

				double power_cost = getRandomValue (0.01, 0.1);
				//double power_cost = 1;

				IoTs_k[i] = new Objectt(i, transPower, channelGain, power_cost, Nodes_k); // int id, double band
				//Objectt(int id, double band, double transPower, double channelGain)
			}


			DT [] DTs_k = new DT [IoT_size];

			for (int i = 0; i < IoT_size; i++) {

				double compR_i = getRandomValue(20, 100); // 20 - 100 MHz

				double raw_size = getRandomValue(1, 5); // 1 - 5 MB
				//double raw_size = 5 + 1 * ( i % 6); // 5 - 1 MB

				//double worker_size = raw_size / 5; // 1 - 5 MB
				double worker_size = raw_size / 2; // 0.5 - 2.5 MB

				int loc_size = (int) (Nodes_k.length * 0.1);

				int [] locations = new int [loc_size]; // to obtain the mobility profile, the probability is the average
				for (int j = 0;  j < loc_size; j++) {
					locations[j] = getRandomIntValue (0, Nodes_k.length-1);
				}


				double proRate = getRandomValue(0.5, 2); //0.5 - 2 MB per ms

				DTs_k[i] = new DT(i, compR_i, locations, raw_size, worker_size, proRate); 
				//public DT (int id, double consump, int[] loc, double raw_size, double worker_size)
				// id, size of each updated of the object, demanded computing resource, instantiation delay, mobility of the object
				// update_size: 2 - 5 MB
				// demanded computing resource: 20 - 200 MHz
				// inst_delay: 10 -30 ms
			}

			model [] models_k= new model[model_size];

			int count = 0;

			for (int i = 0; i < model_size; i++) {

				//double compR_i = 50 + 50*(i%4); // 50 - 200 MHz

				double compR_i = getRandomValue(20, 100); // 20 - 200 MHz
				//double compR_i = 1; // 50 - 100 MHz
				//}

				int length = getRandomIntValue (5, 15); // 5-15
				//int length = num_IoT_devices; // 5-15
				int[] DTs_set = new int[length];

				for (int j = 0; j < DTs_set.length; j++) {
					DTs_set[j] = (count+j)% IoT_size;
				}

				count += length;

				double proRate = getRandomValue (0.5, 2); //0.5 - 2 MB per ms

				models_k[i] = new model(i, length, DTs_set, compR_i, proRate);
			}

			/*
			Request[] Requests_k = new Request[Requests_size];

			for (int i = 0; i < Requests_k.length; i++) {

				int O_id = i% IoT_size; // the location of request i

				int candi_size = 10 + i %11; // each request has 10 -20 candidate IoT devices
				//int candi_size = 25; // each request has 10 -20 candidate IoT devices

				int H = 1; // each request trains 1 round

				int budget = 20 + 10*(i %3); // budegt 20 - 40
				//int budget = 20;

				int[] candi = new int [candi_size];
				for (int j = 0; j<candi_size; j++) {
					candi[j] =(i + j +1) % IoT_size;
				}


				Requests_k[i] = new Request(i, O_id, candi, H, budget, trust_map, interact_map, tao, kappa);
			}
			 */

			System.out.println(num_cloudlets);

			//*****************************************


			//int num = 10; // average the results of 10 requests
			/*
			double alg01_u_num = 0;
			long alg01_t_num = 0;
			for (int count = 0; count < num; count++) {
				res res_alg01_num = alg01(delay_map_k, Nodes_k, Requests_k[count]);
				alg01_u_num += res_alg01_num.getCost();
				alg01_t_num += res_alg01_num.getTime();
				clear(Nodes_k);
			}
			res res_alg01 = new res(alg01_u_num / num, alg01_t_num / num);
			 */

			//res res_alg01 = alg01_t(Nodes_k, Requests_k); // 6 for threshold 50- 150
			//res res_alg01 = alg01(connect_map_k, cost_map_k, Nodes_k, IoTs_k, DTs_k, models_k); // 6 for threshold 50- 150
			res res_alg01 = alg03(connect_map_k, cost_map_k, Nodes_k, IoTs_k, DTs_k, models_k); // 6 for threshold 50- 150
			//res res_alg01 = new res(0,0);
			System.out.println("alg03, done: ");
			clear(Nodes_k);
			clear(IoTs_k);

			//res res_gdy_u = gdy_u_3(connect_map_k, cost_map_k, Nodes_k, IoTs_k, DTs_k, models_k);
			res res_gdy_u = new res(0,0);
			System.out.println("gdy_u, done: ");
			clear(Nodes_k);
			clear(IoTs_k);

			//res res_gdy_m = gdy_m_3(connect_map_k, cost_map_k, Nodes_k, IoTs_k, DTs_k, models_k);
			res res_gdy_m = new res(0,0);
			System.out.println("gdy_m, done: ");
			clear(Nodes_k);
			clear(IoTs_k);

			//res res_opt = opt(connect_map_k, cost_map_k, Nodes_k, IoTs_k, DTs_k, models_k);
			res res_opt = new res(0,0);
			System.out.println("opt_off, done: ");
			clear(Nodes_k);
			clear(IoTs_k);

			//res res_alg02 = alg02(connect_map_k, cost_map_k, Nodes_k, IoTs_k, DTs_k, models_k);
			res res_alg02 = new res(0,0);
			System.out.println("alg02, done: ");
			clear(Nodes_k);
			clear(IoTs_k);

			//res res_gdy_u_on = heu02(connect_map_k, cost_map_k, Nodes_k, IoTs_k, DTs_k, models_k);
			res res_gdy_u_on = new res(0,0);
			System.out.println("gdy_u_on, done: ");
			clear(Nodes_k);
			clear(IoTs_k);

			//res res_gdy_u_on = heu02(connect_map_k, cost_map_k, Nodes_k, IoTs_k, DTs_k, models_k);
			res res_gdy_m_on = new res(0,0);
			System.out.println("gdy_m_on, done: ");
			clear(Nodes_k);
			clear(IoTs_k);

			//res res_opt_on = opt(connect_map_k, cost_map_k, Nodes_k, IoTs_k, DTs_k, models_k);
			res res_opt_on = new res(0,0);
			System.out.println("opt_on, done: ");
			clear(Nodes_k);
			clear(IoTs_k);
			//clear(Requests_k);

			//res res_alg03 = alg03(connect_map_k, cost_map_k, Nodes_k, IoTs_k, DTs_k, models_k);
			//res res_alg03 = new res(0,0);
			//System.out.println("alg03, done: ");

			//*****************************************

			NumberFormat nf = NumberFormat.getInstance();
			nf.setGroupingUsed(false);

			String u_alg01_str = nf.format(res_alg01.getCost());
			String u_gdy_u_str = nf.format(res_gdy_u.getCost());
			String u_gdy_m_str = nf.format(res_gdy_m.getCost());
			String u_opt_str = nf.format(res_opt.getCost());

			String u_alg02_str = nf.format(res_alg02.getCost());
			//String u_alg03_str = nf.format(res_alg03.getCost());
			String u_gdy_u_on_str = nf.format(res_gdy_u_on.getCost());
			String u_gdy_m_on_str = nf.format(res_gdy_m_on.getCost());
			String u_opt_on_str = nf.format(res_opt_on.getCost());

			//*****************************************


			String t_alg01_str = nf.format(res_alg01.getTime());
			String t_opt_str = nf.format(res_opt.getTime());
			String t_gdy_u_str = nf.format(res_gdy_u.getTime());
			String t_gdy_m_str = nf.format(res_gdy_m.getTime());

			String t_alg02_str = nf.format(res_alg02.getTime());
			//String t_alg03_str = nf.format(res_alg03.getTime());
			String t_gdy_u_on_str = nf.format(res_gdy_u_on.getTime());
			String t_gdy_m_on_str = nf.format(res_gdy_m_on.getTime());

			//*****************************************

			String logt_alg01_str = nf.format(res_alg01.getLogTime());
			String logt_opt_str = nf.format(res_opt.getLogTime());
			String logt_gdy_u_str = nf.format(res_gdy_u.getLogTime());
			String logt_gdy_m_str = nf.format(res_gdy_m.getLogTime());

			String logt_alg02_str = nf.format(res_alg02.getLogTime());
			//String logt_alg03_str = nf.format(res_alg03.getLogTime());
			String logt_gdy_u_on_str = nf.format(res_gdy_u_on.getLogTime());
			String logt_gdy_m_on_str = nf.format(res_gdy_m_on.getLogTime());
			//*****************************************

			alg01_utility = alg01_utility +  u_alg01_str + ", ";
			gdy_u_utility = gdy_u_utility +  u_gdy_u_str + ", ";
			gdy_m_utility = gdy_m_utility +  u_gdy_m_str + ", ";
			opt_utility = opt_utility +  u_opt_str + ", ";

			alg02_utility = alg02_utility +  u_alg02_str + ", ";
			//alg03_utility = alg03_utility +  u_alg03_str + ", ";
			gdy_u_on_utility = gdy_u_on_utility +  u_gdy_u_on_str + ", ";
			gdy_m_on_utility = gdy_m_on_utility +  u_gdy_m_on_str + ", ";
			opt_on_utility = opt_on_utility +  u_opt_on_str + ", ";

			//*****************************************

			alg01_time = alg01_time +  t_alg01_str + ", ";
			opt_time = opt_time +  t_opt_str + ", ";
			gdy_u_time = gdy_u_time +  t_gdy_u_str + ", ";
			gdy_m_time = gdy_m_time +  t_gdy_m_str + ", ";

			alg02_time = alg02_time +  t_alg02_str + ", ";
			//alg03_time = alg03_time +  t_alg03_str + ", ";
			gdy_u_on_time = gdy_u_on_time +  t_gdy_u_on_str + ", ";
			gdy_m_on_time = gdy_m_on_time +  t_gdy_m_on_str + ", ";


			//*****************************************

			alg01_logtime = alg01_logtime +  logt_alg01_str + ", ";
			opt_logtime = opt_logtime +  logt_opt_str + ", ";
			gdy_u_logtime = gdy_u_logtime +  logt_gdy_u_str + ", ";
			gdy_m_logtime = gdy_m_logtime +  logt_gdy_m_str + ", ";
			//Wait_logtime = Wait_logtime +  logt_Wait_str + ", ";
			//NoWait_logtime = NoWait_logtime +  logt_NoWait_str + ", ";
			//Random_logtime = Random_logtime +  logt_Random_str + ", ";

			alg02_logtime = alg02_logtime +  logt_alg02_str + ", ";
			//alg03_logtime = alg03_logtime +  logt_alg03_str + ", ";
			gdy_u_on_logtime = gdy_u_on_logtime +  logt_gdy_u_on_str + ", ";
			gdy_m_on_logtime = gdy_m_on_logtime +  logt_gdy_m_on_str + ", ";


			System.out.println("*************************");

		}
		//System.out.println("alg01, utility:");
		System.out.println("alg03, utility:");
		System.out.println(alg01_utility);
		System.out.println("gdy_u, utility:");
		System.out.println(gdy_u_utility);
		System.out.println("gdy_m, utility:");
		System.out.println(gdy_m_utility);
		//System.out.println("opt_off, utility:");
		//System.out.println(opt_utility);
		//System.out.println("Random, utility:");
		//System.out.println(Random_utility);


		//System.out.println("alg02, utility:");
		//System.out.println(alg02_utility);
		//System.out.println("alg03, utility:");
		//System.out.println(alg03_utility);
		//System.out.println("gdy_u_on, utility:");
		//System.out.println(gdy_u_on_utility);
		//System.out.println("gdy_m_on, utility:");
		//System.out.println(gdy_m_on_utility);
		//System.out.println("opt_on, utility:");
		//System.out.println(opt_on_utility);

		System.out.println();

		//System.out.println("alg01, time: ");
		System.out.println("alg03, time: ");
		System.out.println(alg01_time);
		//System.out.println("opt, time: ");
		//System.out.println(opt_time);
		System.out.println("gdy_u, time: ");
		System.out.println(gdy_u_time);
		System.out.println("gdy_m, time: ");
		System.out.println(gdy_m_time);

		//System.out.println("alg02, time: ");
		//System.out.println(alg02_time);
		//System.out.println("alg03, time: ");
		//System.out.println(alg03_time);
		//System.out.println("gdy_u_on, time: ");
		//System.out.println(gdy_u_on_time);
		//System.out.println("gdy_m_on, time: ");
		//System.out.println(gdy_m_on_time);

		System.out.println();

		System.out.println("alg03, logtime: ");
		System.out.println(alg01_logtime);
		//System.out.println("opt, logtime: ");
		//System.out.println(opt_logtime);
		System.out.println("gdy_u, logtime: ");
		System.out.println(gdy_u_logtime);
		System.out.println("gdy_m, logtime: ");
		System.out.println(gdy_m_logtime);

		//System.out.println("alg02, logtime: ");
		//System.out.println(alg02_logtime);
		//System.out.println("alg03, logtime: ");
		//System.out.println(alg03_logtime);
		//System.out.println("gdy_u_on, logtime: ");
		//System.out.println(gdy_u_on_logtime);
		//System.out.println("gdy_m_on, logtime: ");
		//System.out.println(gdy_m_on_logtime);

	}

	public static void main(String[] args) {

		DiffNumOfNodes();


	}
}